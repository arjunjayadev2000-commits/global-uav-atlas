"""Build the Datathon-2026 report (HTML -> PDF via headless Chromium).

Every number in the text is read from data/metrics.json or tables/*.csv, so the report always
matches the analysis pipeline (analysis/run_all.py).

Pipeline: render body (arabic page numbers) -> locate heading/figure markers -> render front matter
with a paginated table of contents, list of figures and list of tables -> merge -> stamp page numbers.
"""

# =====================================================================================================
# ANNOTATED SOURCE - build_report.py: the full technical report (PDF, ~90 pages)
# -----------------------------------------------------------------------------------------------------
# Usage:  cd report && python build_report.py        (run the analysis pipeline first)
# HOW IT WORKS
#   1. build_body() writes the report as HTML, chapter by chapter, using the Doc helper class below.
#      Numbers come from M (data/metrics.json) and T(<table name>) (tables/*.csv) - nothing is typed by hand.
#   2. Headless Chromium prints the body to PDF. Invisible markers (@@S5_2@@ etc.) placed next to every heading,
#      figure and table are then found in the PDF to learn their page numbers, and blanked out.
#   3. The front matter (title page, declaration, abstract, executive summary, lists of figures and tables,
#      contents) is printed with those page numbers, merged in front of the body, and page numbers are stamped.
#   4. The final HTML is also saved to report/_html/ for build_word.py (the editable Word version).
# TO EDIT  Your rank, service number and unit: the RANK / SERVICE_NO / UNIT lines below.
#          Wording: find the chapter in build_body() (search for the '=====' chapter markers).
# =====================================================================================================

import base64
import html
import json
import re
from pathlib import Path

import pymupdf as fitz
import pandas as pd
from playwright.sync_api import sync_playwright

import infographics as IG
import story as ST

ROOT = Path(__file__).resolve().parents[1]
FIG, TAB, OUT = ROOT / "figures", ROOT / "tables", ROOT / "report"
WORD = OUT / "_html"  # intermediate HTML consumed by build_word.py
M = json.loads((ROOT / "data" / "metrics.json").read_text())

# EDIT HERE: replace the three placeholders below with your rank, service number and unit / formation.
AUTHOR = "Arjun Jayadev"
RANK = "[Rank]"
SERVICE_NO = "[Service No]"
UNIT = "[Unit / Formation]"
# Report title and subtitle (also used by the Commander's Edition).
TITLE = "PROJECT DARKWATER"
SUBTITLE = ("Global Conflicts and the Blinding of Supply Chains: Maritime Picture Assurance at Contested Chokepoints, "
            "with Implications for India and the Indian Armed Forces")


# Number formatting helpers: pct(0.742) -> '74%'; n(12345) -> '12,345'.
def pct(x, d=0):
    return f"{x * 100:.{d}f}%"


def n(x):
    return f"{x:,}"


# ------------------------------------------------------------------ numbering registries
# Doc collects the report as HTML pieces and numbers chapters, sections, figures and tables automatically.
# Each heading/figure/table gets a hidden marker so its page number can be found after printing.
class Doc:
    def __init__(self):
        self.ch = 0
        self.fig_no = 0
        self.tab_no = 0
        self.sec = []           # (id, level, label, title)
        self.figs = []          # (id, label, caption)
        self.tabs = []
        self.parts = []

    def add(self, s):
        self.parts.append(s)

    # New chapter: closes the previous one with its 'So what' box, restarts figure/table numbering,
    # and adds the story kicker and 'The story so far' box (from story.py).
    def chapter(self, title, letter=None):
        close = getattr(self, "closes", {}).get(self.ch) if self.ch else None
        if close and not letter and self.ch not in getattr(self, "_closed", set()) or (close and letter and self.ch not in getattr(self, "_closed", set())):
            self._closed = getattr(self, "_closed", set()) | {self.ch}
            what, nxt = close
            nx = f'<span class="next">Next: {nxt}</span>' if nxt else ""
            self.add(f'<div class="sowhat"><span class="lab">So what</span>{what}{nx}</div>')
        self.fig_no = self.tab_no = 0
        if letter:
            self.pfx = letter
            mid = f"SAPP{letter}"
            self.sec.append((mid, 1, "", title))
            self.add(f'<h1 class="chapter"><span class="mk">@@{mid}@@ </span>{title.upper()}</h1>')
            return
        self.ch += 1
        self.pfx = str(self.ch)
        mid = f"S{self.ch}"
        self.sec.append((mid, 1, f"{self.ch}.", title))
        self.add(f'<h1 class="chapter"><span class="mk">@@{mid}@@ </span>{self.ch}.&nbsp;&nbsp;{title.upper()}</h1>')
        kick = getattr(self, "kickers", ST.KICKER)
        if self.ch in kick:
            self.add(f'<div class="kicker">{kick[self.ch]}</div>')
        op = getattr(self, "opens", {}).get(self.ch)
        if op:
            self.add(f'<div class="story"><span class="lab">The story so far</span>{op}</div>')

    # Numbered section heading (level 2 = x.y, level 3 = x.y.z).
    def section(self, num, title, level=2):
        mid = "S" + num.replace(".", "_")
        self.sec.append((mid, level, num, title))
        tag = "h2" if level == 2 else "h3"
        self.add(f'<{tag}><span class="mk">@@{mid}@@ </span>{num}&nbsp;&nbsp;{title}</{tag}>')

    def p(self, *paras):
        for t in paras:
            self.add(f"<p>{t}</p>")

    def bullets(self, items, cls=""):
        self.add(f'<ul class="{cls}">' + "".join(f"<li>{i}</li>" for i in items) + "</ul>")

    # Insert figures/<name>.png with a numbered caption and, if story.py has one, a 'What this shows' line.
    def fig(self, name, caption, width=86, source=None):
        self.fig_no += 1
        label = f"{self.pfx}.{self.fig_no}"
        mid = f"F{label.replace('.', '_')}"
        self.figs.append((mid, label, caption))
        data = base64.b64encode((FIG / f"{name}.png").read_bytes()).decode()
        src = f'<div class="src">Source: {source}</div>' if source else ""
        pl = f'<div class="plain"><b>What this shows:</b> {ST.PLAIN[name]}</div>' if name in ST.PLAIN else ""
        self.add(f'<figure><img src="data:image/png;base64,{data}" style="width:{width}%">'
                 f'<figcaption><span class="mk">@@{mid}@@ </span><b>Figure {label} :</b> {caption}</figcaption>{pl}{src}</figure>')
        return label

    # Insert an HTML infographic (from infographics.py) as a numbered figure.
    def html_fig(self, inner, caption):
        self.fig_no += 1
        label = f"{self.pfx}.{self.fig_no}"
        mid = f"F{label.replace('.', '_')}"
        self.figs.append((mid, label, caption))
        self.add(f'<figure>{inner}<figcaption><span class="mk">@@{mid}@@ </span><b>Figure {label} :</b> {caption}</figcaption></figure>')
        return label

    # Insert a pandas table as a numbered, styled HTML table (numbers formatted automatically).
    def table(self, df, caption, fmt=None, widths=None, small=False, note=None, breakable=False):
        self.tab_no += 1
        label = f"{self.pfx}.{self.tab_no}"
        mid = f"T{label.replace('.', '_')}"
        self.tabs.append((mid, label, caption))
        fmt = fmt or {}
        head = "".join(f"<th>{html.escape(str(c))}</th>" for c in df.columns)
        rows = []
        for _, r in df.iterrows():
            cells = []
            for c in df.columns:
                v = r[c]
                if c in fmt:
                    v = fmt[c](v)
                elif isinstance(v, float):
                    v = f"{v:,.0f}" if (v.is_integer() or abs(v) >= 100) else f"{v:,.2f}"
                elif isinstance(v, (int,)) and not isinstance(v, bool):
                    v = f"{v:,}"
                cells.append(f"<td>{v}</td>")
            rows.append("<tr>" + "".join(cells) + "</tr>")
        cls = "tbl small" if small else "tbl"
        nt = f'<div class="src">{note}</div>' if note else ""
        brk = ' style="page-break-inside:auto"' if breakable else ""
        self.add(f'<div class="tblwrap"{brk}><div class="tcap"><span class="mk">@@{mid}@@ </span><b>Table {label} :</b> {caption}</div>'
                 f'<table class="{cls}"><thead><tr>{head}</tr></thead><tbody>{"".join(rows)}</tbody></table>{nt}</div>')
        return label

    def eq(self, body, num):
        self.add(f'<div class="eq"><span class="eqb">{body}</span><span class="eqn">({num})</span></div>')

    def callout(self, t):
        self.add(f'<div class="callout">{t}</div>')


# Read tables/<name>.csv (a result table written by the analysis stages).
def T(name):
    return pd.read_csv(TAB / f"{name}.csv")


# Print styling for the PDF: A4, Times-style body, navy headings, table and box styles.
CSS = """
@page { size: A4; margin: 24mm 22mm 22mm 26mm; }
* { box-sizing: border-box; }
body { font-family: 'Liberation Serif', 'Times New Roman', serif; font-size: 11pt; line-height: 1.38; color: #111; }
p { text-align: justify; margin: 0 0 8pt 0; }
h1.chapter { page-break-before: always; font-size: 15pt; margin: 0 0 14pt 0; }
h2 { font-size: 12.5pt; margin: 14pt 0 6pt 0; page-break-after: avoid; }
h3 { font-size: 12pt; font-style: italic; margin: 10pt 0 4pt 0; page-break-after: avoid; }
ul { margin: 0 0 8pt 0; padding-left: 22pt; } li { text-align: justify; margin-bottom: 3pt; }
ul.alpha { list-style: lower-alpha; }
figure { margin: 6pt 0 9pt 0; text-align: center; page-break-inside: avoid; }
figcaption { font-size: 10.5pt; margin-top: 4pt; text-align: center; }
.src { font-size: 9pt; color: #555; text-align: center; margin-top: 2pt; }
.tblwrap { margin: 10pt 0 12pt 0; page-break-inside: avoid; }
.tcap { font-size: 10.5pt; text-align: center; margin-bottom: 4pt; }
table.tbl { border-collapse: collapse; width: 100%; font-family: 'Liberation Sans', Arial, sans-serif; font-size: 8.8pt; line-height: 1.3; }
table.tbl.small { font-size: 8pt; }
table.tbl th { background: #1f3b5c; color: #fff; font-weight: bold; padding: 4pt 5pt; text-align: left; border: 0.5pt solid #1f3b5c; }
table.tbl tr { page-break-inside: avoid; }
table.tbl td { padding: 3pt 5pt; border: 0.5pt solid #c9c8c2; vertical-align: top; }
table.tbl tr:nth-child(even) td { background: #f4f3ef; }
.mk { color: #fff; font-size: 1pt; line-height: 0; }
.eq { display: flex; justify-content: space-between; align-items: center; margin: 6pt 0 8pt 30pt; font-style: italic; }
.eqb { font-family: 'Liberation Serif', serif; font-size: 12pt; } .eqn { font-style: normal; }
.callout { border-left: 3pt solid #1f3b5c; background: #eef2f7; padding: 7pt 10pt; margin: 8pt 0 10pt 0; font-size: 11pt; text-align: justify; page-break-inside: avoid; }
.center { text-align: center; }
.front h1 { text-align: center; font-size: 14pt; margin: 0 0 16pt 0; }
.toc { width: 100%; border-collapse: collapse; font-size: 11pt; }
.toc td { padding: 2pt 4pt; vertical-align: top; } .toc td.pg { text-align: right; width: 40pt; }
.toc tr.l1 td { font-weight: bold; padding-top: 5pt; } .toc tr.l3 td.t { padding-left: 34pt; font-size: 10.5pt; }
.toc tr.l2 td.t { padding-left: 18pt; }
.toc td.t { border-bottom: 0.5pt dotted #aaa; }
.flow { display: flex; flex-wrap: wrap; gap: 6pt; justify-content: center; font-family: 'Liberation Sans', sans-serif; font-size: 8.5pt; line-height: 1.25; }
.flow .col { width: 23.5%; display: flex; flex-direction: column; gap: 5pt; }
.flow .hd { background: #1f3b5c; color: #fff; padding: 5pt; font-weight: bold; text-align: center; border-radius: 3pt; }
.flow .bx { border: 0.8pt solid #1f3b5c; padding: 4pt 5pt; border-radius: 3pt; background: #f4f6f9; text-align: left; }
.kpis { display: flex; gap: 6pt; margin: 8pt 0 10pt 0; font-family: 'Liberation Sans', sans-serif; page-break-inside: avoid; }
.kpi { flex: 1; border: 0.6pt solid #c9c8c2; border-top: 3pt solid #1f3b5c; padding: 5pt 6pt; }
.kpi .v { font-size: 15pt; font-weight: bold; color: #1f3b5c; } .kpi .l { font-size: 7.8pt; color: #333; line-height: 1.25; }
.titlepage { text-align: center; padding-top: 18mm; }
.titlepage .t1 { font-size: 19pt; font-weight: bold; line-height: 1.3; margin-bottom: 10pt; }
.titlepage .t2 { font-size: 13pt; font-style: italic; margin-bottom: 36pt; }
.titlepage .t3 { font-size: 12pt; margin: 4pt 0; }
.sig { margin-top: 40pt; display: flex; justify-content: space-between; }
.pb { page-break-before: always; }
.rag { font-weight: bold; padding: 1pt 5pt; border-radius: 2pt; color: #fff; }
.rag.red { background: #c62828; } .rag.amber { background: #e08a00; } .rag.green { background: #2e7d32; }
.bluf { border: 1.2pt solid #1f3b5c; padding: 8pt 10pt; margin-bottom: 8pt; background: #eef2f7; font-size: 11pt; text-align: justify; }
.es h2 { font-size: 11.5pt; margin: 8pt 0 3pt 0; } .es p, .es li { font-size: 10.5pt; line-height: 1.38; margin-bottom: 3pt; }
.kicker { font-family: 'Liberation Sans', sans-serif; font-size: 9pt; color: #9a4a3a; text-transform: uppercase; letter-spacing: .6pt; margin: -8pt 0 8pt 0; font-weight: bold; }
.story { border: .8pt solid #d9c7a3; background: #fbf6ec; border-radius: 4pt; padding: 7pt 10pt; margin: 4pt 0 12pt 0; font-size: 11pt; text-align: justify; page-break-inside: avoid; }
.story .lab, .sowhat .lab { font-family: 'Liberation Sans', sans-serif; font-size: 8pt; font-weight: bold; letter-spacing: .5pt; text-transform: uppercase; color: #9a4a3a; display: block; margin-bottom: 2pt; }
.sowhat { border: .8pt solid #1f3b5c; background: #eef2f7; border-radius: 4pt; padding: 7pt 10pt; margin: 14pt 0 4pt 0; font-size: 11pt; text-align: justify; page-break-inside: avoid; }
.sowhat .lab { color: #1f3b5c; } .sowhat .next { display: block; margin-top: 4pt; font-style: italic; color: #1f3b5c; }
.plain { font-family: 'Liberation Sans', sans-serif; font-size: 8.8pt; color: #333; background: #f7f7f4; border-left: 3pt solid #9a4a3a; padding: 3pt 7pt; margin: 4pt auto 0 auto; text-align: left; max-width: 94%; }
.code { font-family: 'Liberation Mono', monospace; font-size: 8pt; line-height: 1.3; background: #f6f6f4; border: 0.5pt solid #ddd; padding: 6pt; white-space: pre-wrap; text-align: left; }
"""


def st_null(M):
    st = pd.read_csv(TAB / "t11_2_stasis.csv")
    r = st[(st.Sea == "Hormuz + Persian Gulf") & (st.Population == "dark")].iloc[0]
    return f"{r['Crowding null %']:.1f}"


# THE REPORT TEXT. Chapters follow the thesis format: Introduction -> Literature -> Background -> Data ->
# analysis chapters -> Inference -> Impact on the globe, India and the Armed Forces -> Way Forward ->
# Conclusion.
def build_body():
    d = Doc()
    d.opens, d.closes = ST.openings(M), ST.closings(M)
    # ================================================================== 1 INTRODUCTION
    d.chapter("Introduction")
    d.p(
        "Around 80 per cent of world merchandise trade by volume moves by sea, and a large share of it passes through a handful "
        "of narrow chokepoints: the Strait of Hormuz, Bab-el-Mandeb, the Suez Canal, the Strait of Malacca, the Bosphorus and a few others "
        "[1, 2]. When conflict reaches one of these straits, the effect spreads through energy prices, freight rates, insurance "
        "premia and delivery lead-times to every economy that depends on them. Between October 2023 and June 2026 the Middle East "
        "produced two such shocks in quick succession. The first was the Houthi anti-shipping campaign in the Red Sea and Gulf of Aden, which "
        "diverted a large part of Asia-Europe container traffic around the Cape of Good Hope [1]. The second was the regional war that broke out on "
        "28 February 2026 and carried missile and drone strikes to the Iranian coast and the Gulf Cooperation Council (GCC) states around the Strait of Hormuz.",
        "Conflict affects shipping in two ways. The obvious effect is physical: ships are struck, diverted or held in port. The less "
        "obvious effect is <b>informational</b>. Ships in or near a war zone switch off or manipulate their Automatic Identification "
        "System (AIS) transponders to avoid being targeted. Electronic warfare jams and spoofs satellite navigation. Sanctions-evading fleets operate dark by design. The common maritime "
        "picture, which navies, insurers, port authorities and logisticians all rely on, then loses its identities. The Datathon-2026 "
        "problem statement calls this an <i>identification crisis</i> and asks participants to find AIS dead zones and relate them "
        "to local conflicts such as those in the Black Sea and the Persian Gulf [3].",
        "This report takes up that problem with two unclassified datasets from the Datathon repository and a set of descriptive, "
        "diagnostic, predictive and prescriptive techniques. The first dataset is eleven and a half years of weekly Middle-East conflict "
        "events (ACLED). The second is 1-14 March 2026 of Sentinel-1 synthetic-aperture-radar (SAR) vessel detections matched against AIS. "
        "The report works from the evidence to inferences, then to the impact on the globe, on India and on the Indian Armed "
        "Forces, and ends with a way forward and a conclusion, each traced back to a finding in the analysis.")
    d.callout(
        "<b>Thesis.</b> Conflict near a maritime chokepoint shows up in the data first as the <i>blinding</i> of the "
        "supply chain: large, AIS-obligated ships vanish from the cooperative picture. Only after that does it show up as the "
        "physical disruption of trade flows. In March 2026, large ships in the Gulf war zone were "
        f"{M['large_rr']:.1f} times more likely to be AIS-dark than large ships elsewhere, and "
        "distance from the fighting predicts darkness even in regions the model has never seen. Disruption episodes have a heavy "
        f"tail: about {pct(M['km_p_gt_spr'])} outlast the ~9.5 days of India's strategic petroleum reserve. India's "
        "economic and military exposure therefore has to be managed as one data problem, joining maritime domain awareness with "
        "stock-holding policy.")

    d.section("1.1", "Problem Statement")
    d.p("Can open conflict and satellite data be used to (i) measure how Middle-East conflict intensity near maritime "
        "chokepoints has changed, (ii) locate and explain AIS dark zones and relate them to that conflict, (iii) predict "
        "where AIS darkness will appear, and (iv) turn the results into quantified guidance for India's supply-chain security and "
        "for the Indian Armed Forces' logistics and operational preparedness?")
    d.section("1.2", "Aim")
    d.p("To derive data-driven insights on the impact of global, and in particular Middle-East, conflicts on maritime supply "
        "chains, with a focus on AIS dark zones and chokepoint disruption, and to recommend measures for India and the Indian Armed Forces.")
    d.section("1.3", "Objectives")
    d.bullets([
        "Build a clean, reproducible data pipeline for the ACLED conflict and Sentinel-1 SAR/AIS datasets (Chapter 4).",
        "Characterise the Middle-East conflict system from 2015 to 2026, detect statistically significant regime shifts and measure the "
        "spill-over of the 2026 war onto the GCC energy coast (Chapter 5).",
        "Construct a Chokepoint Conflict Intensity Index (CCII), forecast it and model how long disruption episodes last with "
        "survival analysis (Chapter 6).",
        "Map AIS darkness worldwide, test whether it is significantly higher in war zones, find statistically significant "
        "dark hot spots and dark-vessel clusters, and profile the identity and registry of ships in the war zone (Chapter 7).",
        "Train and validate a model that predicts AIS dark spots from conflict geography (Chapter 8).",
        "Measure the economic transmission of the conflict (oil price, rupee, India's import bill) with open-source data, and test "
        "the early-warning indicators out-of-sample (Chapter 9).",
        "Draw inferences from the findings and assess their impact on the globe, India and the Indian Armed Forces, with a "
        "prescriptive stock-cover model, a way forward and a conclusion (Chapters 10-15).",
    ], "alpha")
    d.section("1.4", "Hypotheses")
    d.table(pd.DataFrame([
        ("H1", "Middle-East political violence underwent statistically significant regime shifts that coincide with the 2023 and 2026 wars.", "Change-point detection (PELT), Mann-Whitney U"),
        ("H2", "The 2026 war moved conflict onto the maritime/energy littoral (GCC, Hormuz) and the Red Sea threat moved offshore.", "Littoral and at-sea indices, rate multipliers"),
        ("H3", "Large (>=100 m) vessels are significantly more often AIS-dark in war zones than elsewhere.", "Chi-square, odds ratio, Wilson intervals"),
        ("H4", "AIS darkness clusters in statistically significant hot spots that coincide with conflict chokepoints.", "Getis-Ord Gi*, DBSCAN"),
        ("H5", "Proximity to conflict predicts AIS darkness out-of-region.", "Logit, gradient-boosted trees, leave-one-region-out CV"),
        ("H6", "Chokepoint disruption durations are heavy-tailed and often exceed India's strategic oil cover.", "Kaplan-Meier, Cox PH, expected shortfall"),
        ("H7", "Conflict shocks transmit to the oil price and the rupee, and the size of the shock depends on whether a detour exists.", "Event study, Granger causality, pass-through regression"),
    ], columns=["#", "Hypothesis", "Test"]), "Hypotheses tested in this study")
    d.section("1.5", "Methodology Overview")
    d.html_fig(IG.methodology(), "Analytical framework - from data to decision (SmartArt)")
    d.p("The work was done in Python 3.11 (pandas, NumPy, SciPy, statsmodels, scikit-learn, ruptures, Matplotlib/Basemap). "
        "The cleaned star-schema tables are exported for the Power BI (.pbix) dashboard that accompanies the report (Appendix B). "
        "Running the whole pipeline with a single command (<i>analysis/run_all.py</i>) regenerates every figure, table and number in this report from the raw files.")
    d.section("1.6", "Organisation of the Report")
    d.p("Chapter 2 reviews the literature and Chapter 3 sets out the theory behind the techniques used. Chapter 4 covers data "
        "pre-processing. Chapters 5 to 8 present the analysis: the conflict landscape, chokepoint intensity and disruption survival, "
        "AIS dark zones, and the predictive model. Chapter 9 adds open-source economic data. Chapter 10 draws the inferences. Chapters 11, 12 and 13 "
        "assess the impact on the globe, on India and on the Indian Armed Forces. Chapter 14 sets out the way forward and Chapter 15 concludes, "
        "followed by the references and appendices.")

    # ================================================================== 2 LITERATURE REVIEW
    d.chapter("Literature Review")
    d.p("The study drew on work in conflict-event data, maritime remote sensing, maritime security and statistical "
        "methods. The works that shaped the study most are summarised below.")
    d.bullets([
        "<b>Raleigh et al. (2010)</b> introduced the Armed Conflict Location and Event Data (ACLED) project, which codes political "
        "violence and protest events by date, location, actor and type [4]. The event typology used here (battles, explosions/remote "
        "violence, violence against civilians, riots, protests, strategic developments) and the weekly ADMIN1 aggregates come from ACLED. "
        "Aggregation to province centroids limits spatial precision, so this study measures distance to conflict at ADMIN1 resolution "
        "and treats the at-sea regions separately.",
        "<b>Paolo et al. (2024)</b>, writing in <i>Nature</i>, combined Sentinel-1 SAR imagery with deep learning and AIS to map "
        "industrial activity at sea. They found that about 72-76 per cent of the world's industrial fishing vessels and about a quarter of "
        "transport and energy vessels are not publicly tracked [5]. The SAR detections, presence, length and fishing scores and the "
        "AIS-matching logic in the Datathon SAR dataset follow the same approach. That result gives a <i>baseline</i> level of darkness against which "
        "conflict-related darkness can be measured.",
        "<b>UNCTAD, Review of Maritime Transport (2024)</b> documented the Red Sea crisis: collapsing Suez and Bab-el-Mandeb "
        "transits, Cape of Good Hope diversions adding roughly 10-14 days to Asia-Europe voyages, and the knock-on effects on freight "
        "rates, emissions and developing-country trade costs [1]. It frames the physical-disruption channel that this study pairs "
        "with the informational (AIS) channel.",
        "<b>U.S. Energy Information Administration (2024)</b>, <i>World Oil Transit Chokepoints</i>, estimates that flows through the "
        "Strait of Hormuz are about one-fifth of global petroleum liquids consumption, with most of them going to Asian buyers "
        "including India, and that alternative pipeline bypass capacity is limited [2]. This makes Hormuz the single most "
        "consequential chokepoint for India.",
        "<b>Killick, Fearnhead and Eckley (2012)</b> proposed PELT (Pruned Exact Linear Time), an exact change-point search with "
        "linear cost [6]. <b>Truong, Oudre and Vayatis (2020)</b> reviewed offline change-point methods and released the "
        "<i>ruptures</i> library used here [7].",
        "<b>Getis and Ord (1992) and Ord and Getis (1995)</b> developed the G and Gi* local statistics for finding significant spatial "
        "clusters of high or low values (hot and cold spots) [8, 9]. <b>Ester et al. (1996)</b> proposed DBSCAN, a density-based "
        "clustering algorithm that finds arbitrarily shaped clusters and treats sparse points as noise [10]. It suits the "
        "detection of anchorages and ship-to-ship transfer areas.",
        "<b>Kaplan and Meier (1958)</b> and <b>Cox (1972)</b> established the non-parametric survival estimator and the "
        "proportional-hazards model [11, 12]. The author's earlier work on predictive maintenance of armoured vehicles applied the "
        "same techniques to equipment time-to-failure data [13]. Here they are transferred to the time-to-end of chokepoint "
        "disruption episodes.",
        "<b>Roberts et al. (2017)</b> showed that ordinary random cross-validation overstates model skill when data are spatially "
        "autocorrelated and recommended blocked (e.g. leave-one-region-out) validation [14]. <b>Friedman (2001)</b> introduced "
        "gradient boosting [15]. <b>Hyndman and Athanasopoulos (2021)</b> give the forecasting practice (ARIMA, exponential smoothing, "
        "hold-out back-testing) followed here [16].",
    ], "alpha")
    d.p("<b>Gap addressed.</b> The literature treats conflict data, SAR/AIS data and supply-chain economics separately. "
        "No study found joins weekly conflict intensity at chokepoints to SAR-observed AIS darkness during a live war. Nor has "
        "any study turned the resulting disruption-duration distribution into a stock-holding decision for an Indian user. That join is "
        "what this study contributes.")

    # ================================================================== 3 BACKGROUND
    d.chapter("Background")
    d.section("3.1", "Maritime Chokepoints and Supply Chains")
    d.p("A chokepoint is a narrow channel on a widely used sea route that cannot easily be bypassed. Closing or degrading one "
        "adds distance, time and insurance cost to every voyage that depends on it. For some cargoes (Gulf crude, LPG and LNG, "
        "Qatari gas, Gulf fertiliser) there is little or no alternative supply in the short run. The Strait of Hormuz (~39 km wide at its "
        "narrowest point) connects the Persian Gulf producers to the Arabian Sea. Bab-el-Mandeb (~29 km) connects the Gulf of Aden to the "
        "Red Sea and the Suez Canal. Both lie within 2,000-3,000 km of India's west coast.")
    d.html_fig(IG.theatre_map(M, base64.b64encode((FIG / "base_theatre.png").read_bytes()).decode()),
               "Theatre of study: India's western sea lines of communication, chokepoints and headline findings (infographic; "
               "ports from Natural Earth, dashed lines are schematic sea routes)")
    d.section("3.2", "AIS, SAR and the Identification Crisis")
    d.p("<b>AIS</b> is a VHF transponder system that broadcasts a ship's identity (MMSI), position, course and speed. Under SOLAS "
        "Chapter V, Regulation 19, AIS is mandatory for ships of 300 gross tonnage and above on international voyages, cargo ships of 500 GT "
        "and above, and all passenger ships [17]. The first three digits of the MMSI, the Maritime Identification Digits (MID), identify "
        "the flag state. AIS is cooperative: a ship can switch it off, transmit a false identity, or be displaced by GNSS "
        "spoofing so that its reported position no longer matches its real one.",
        "<b>SAR</b> satellites such as Sentinel-1 image the sea surface day and night through cloud. A ship shows up as a bright return "
        "whatever it chooses to transmit. Matching SAR detections to AIS tracks at the image time separates <i>cooperative</i> "
        "(matched) ships from <i>non-cooperative</i> or <i>dark</i> (unmatched) ones. Small craft are dark almost everywhere because they are not "
        "required to carry AIS. A dark ship over 100 m long, which is almost certainly AIS-obligated, is an anomaly. This study uses the "
        "large-ship dark share as its main indicator of the identification crisis, and calls it the <b>Strategic Dark Ratio (SDR)</b>: "
        "the share of SOLAS-class hulls (&ge;100 m) seen by radar in a pass that are not matched to AIS. Because both counts come from "
        "the same satellite image at the same instant, the SDR is not distorted by how often the satellite passes or how much sea it covers.",
        "Three questions must be kept apart: <b>presence</b> (is a hull physically there?), <b>identification</b> (does it say who it is?) "
        "and <b>movement</b> (is it transiting or held?). A fourth, <b>throughput</b>, asks what cargo reaches the economy. No single sensor "
        "answers all four, and an AIS-derived traffic count answers only the second. Ensuring that the picture used for military, shipping "
        "and energy decisions still represents physical activity is called here <b>Maritime Picture Assurance</b>.")
    d.section("3.3", "Analytical Techniques")
    d.section("3.3.1", "Proportions, confidence intervals and association", 3)
    d.p("The share of dark ships in a region is a binomial proportion p = x / n. Its 95 per cent Wilson score interval [18] is")
    d.eq("( p + z²/2n ± z &radic;( p(1-p)/n + z²/4n² ) ) / ( 1 + z²/n ),&nbsp;&nbsp; z = 1.96", "3.1")
    d.p("Association between war-zone location and darkness is tested with Pearson's chi-square on the 2x2 contingency table, and its "
        "strength is expressed as the relative risk RR = p<sub>war</sub> / p<sub>rest</sub> and the odds ratio "
        "OR = (a&middot;d)/(b&middot;c). Differences in weekly event counts between periods are tested with the non-parametric "
        "Mann-Whitney U test, which assumes no particular distribution.")
    d.section("3.3.2", "Change-point detection (PELT)", 3)
    d.p("For a weekly series y<sub>1..T</sub>, PELT finds the change-points &tau;<sub>1</sub>&lt;...&lt;&tau;<sub>m</sub> that minimise")
    d.eq("&Sigma;<sub>i=0..m</sub> C( y<sub>&tau;i+1 : &tau;i+1</sub> ) + &beta; m ,&nbsp;&nbsp; C = &Sigma;( y<sub>t</sub> - &ybar; )²  (L2 cost)", "3.2")
    d.p("where &beta; is a penalty that prevents over-segmentation. The series was standardised, a penalty of 12 and a minimum segment of three weeks were used, and the search was exact (jump = 1).")
    d.section("3.3.3", "Local spatial statistics: Getis-Ord Gi*", 3)
    d.p("For grid cell i with value x<sub>j</sub> (dark share) and binary neighbour weights w<sub>ij</sub> (the cell itself and its eight neighbours):")
    d.eq("G<sub>i</sub>* = ( &Sigma;<sub>j</sub> w<sub>ij</sub>x<sub>j</sub> - X&#772; &Sigma;<sub>j</sub> w<sub>ij</sub> ) / ( S &radic;( [ n&Sigma;w<sub>ij</sub>² - (&Sigma;w<sub>ij</sub>)² ] / (n-1) ) )", "3.3")
    d.p("G<sub>i</sub>* is a z-score. Values above 1.96 mark a statistically significant hot spot at the 5 per cent level.")
    d.section("3.3.4", "Density clustering (DBSCAN)", 3)
    d.p("DBSCAN groups points that have at least <i>minPts</i> neighbours within radius &epsilon;. Using the haversine metric, &epsilon; = 25 km and "
        "minPts = 15 on dark ships of 100 m and over, it finds anchorages and loitering or transfer areas where large "
        "ships gather with their AIS off.")
    d.section("3.3.5", "Forecasting", 3)
    d.p("The weekly Hormuz index is log-transformed (y' = ln(1+y)) and modelled as ARIMA(1,0,1) with a constant:")
    d.eq("y'<sub>t</sub> = c + &phi; y'<sub>t-1</sub> + &theta; &epsilon;<sub>t-1</sub> + &epsilon;<sub>t</sub>", "3.4")
    d.p("It is benchmarked against a naive forecast and damped-trend exponential smoothing on a 12-week hold-out.")
    d.section("3.3.6", "Survival analysis", 3)
    d.p("A <i>disruption episode</i> is a run of weeks in which a theatre's index is above its threshold (baseline mean + 3 SD). "
        "Its duration T is the survival time, and an episode still under way at the end of the data is right-censored. The Kaplan-Meier "
        "estimator of S(t) = P(T &gt; t) is")
    d.eq("S&#770;(t) = &Pi;<sub>t<sub>i</sub> &le; t</sub> ( 1 - d<sub>i</sub> / n<sub>i</sub> )", "3.5")
    d.p("where d<sub>i</sub> episodes end at t<sub>i</sub> out of n<sub>i</sub> still at risk. Covariate effects are estimated "
        "with the Cox proportional-hazards model h(t|x) = h<sub>0</sub>(t) exp(&beta;'x), and theatres are compared with the log-rank test.")
    d.section("3.3.7", "Classification and spatial cross-validation", 3)
    d.p("The probability that a detected ship is dark is modelled with logistic regression, logit(p) = &beta;<sub>0</sub> + &beta;'x, "
        "which gives interpretable odds ratios, and with histogram gradient-boosted trees with monotonic constraints, which capture "
        "non-linear effects. Skill is measured by leave-one-region-out cross-validation, so every prediction is made for a sea "
        "region the model did not see in training [14], and reported as ROC-AUC, PR-AUC and Brier score.")
    d.section("3.3.8", "Expected shortfall of a stock policy", 3)
    d.p("If a disruption lasts T days and stock covers S days, the uncovered days are (T - S)<sup>+</sup>. With the Kaplan-Meier curve,")
    d.eq("E[ (T - S)<sup>+</sup> ] = &int;<sub>S</sub><sup>&infin;</sup> S&#770;(t) dt", "3.6")
    d.p("This turns the disruption-duration distribution into a stock-holding decision curve (Section 13.5).")

    # ================================================================== 4 DATA PREPROCESSING
    d.chapter("Data Preprocessing")
    d.p("Pre-processing is the backbone of any statistical model. Both datasets were loaded into pandas, validated, cleaned, "
        "enriched with derived features and written to a clean columnar store (Parquet). The two datasets are summarised below.")
    d.table(T("t4_1_acled_summary"), "Summary of the conflict dataset (ACLED Middle-East weekly aggregates)")
    d.table(T("t4_2_sar_summary"), "Summary of the maritime dataset (Sentinel-1 SAR detections matched to AIS)")
    d.p("<b>Note on coverage.</b> Although the SAR file is named <i>indian ocean vessel</i>, its detections cover the world "
        f"(latitude -56&deg; to 75&deg;), with {n(M['sar_scenes'])} Sentinel-1A scenes. This allows a controlled comparison: "
        "war zones (Gulf, Black Sea) against India's seas and the rest of the world, all imaged by the same sensor in the same fortnight.")
    d.table(T("t4_4_attributes"), "Data headings analysed", small=True)
    d.section("4.1", "Cleaning")
    d.table(T("t4_3_cleaning_log").assign(Count=lambda x: x.Count.map(lambda v: f"{v:,}")), "Data-cleaning log")
    d.bullets([
        "<b>Temporal integrity.</b> One partial week (27 Dec 2014) was dropped so that every year is complete. Weeks were re-indexed to a regular 7-day "
        "frequency, with zero-filling, before any time-series operation.",
        "<b>Missing values.</b> POPULATION_EXPOSURE is missing in 30,965 rows, mostly sea areas and sparsely populated "
        "provinces. It was imputed with the median of the same ADMIN1 unit, or 0 where the unit never reports it. No other field had "
        "missing values.",
        f"<b>Confidence filter.</b> {n(M['sar_low_conf_dropped'])} SAR detections with presence score &lt; 0.80 were dropped "
        "to remove sea clutter, wakes and ambiguous returns.",
        f"<b>Identity validity.</b> {n(M['sar_mmsi_malformed'])} MMSIs outside the ship-station range (MID 2xx-7xx) were flagged as "
        "malformed and kept for the identity-integrity analysis (Section 7.7).",
        "<b>Definition of darkness.</b> <i>Dark</i> = matched_category 'unmatched' (no confident AIS association). "
        f"This covers {pct(M['sar_dark_share'], 1)} of detections. A stricter definition (no candidate MMSI at all, "
        f"{pct(M['sar_dark_strict_share'], 1)}) was used as a robustness check and gives the same regional ranking.",
    ])
    d.section("4.2", "Feature Engineering")
    d.bullets([
        "<b>Sea region</b>: 17 analyst-defined boxes (Strait of Hormuz, Persian Gulf, Gulf of Oman, Red Sea, Bab-el-Mandeb, Gulf of Aden, "
        "Arabian Sea, Bay of Bengal, Strait of Malacca, etc.), grouped into zones: Gulf war zone, Black Sea war zone, Red Sea zone, India's seas, rest of world.",
        "<b>Size class</b> from SAR length (&lt;25, 25-40, 40-100, 100-200, &gt;200 m). The <i>large</i> flag (&ge;100 m) marks ships that almost certainly carry AIS.",
        "<b>Flag state</b> decoded from the MID and classed as national flag, flag of convenience (ITF list) or shadow-fleet-associated registry.",
        "<b>Distance to the nearest chokepoint</b> (haversine) for every ship and every ADMIN1 centroid.",
        "<b>Conflict exposure</b> of every ship: distance to the nearest ADMIN1 with political violence in the war weeks overlapping the "
        "SAR window, and the number of such events within 500 km (BallTree haversine queries). At-sea ACLED rows carry a nominal "
        "basin centroid rather than a real position, so they were excluded from this spatial join.",
        "<b>Conflict flags</b>: political violence, remote violence (air/drone/missile/artillery), stand-off strike, GCC, maritime.",
    ])

    # ================================================================== 5 CONFLICT LANDSCAPE
    d.chapter("Conflict Landscape of the Middle East, 2015-2026")
    d.p(f"The ACLED data record {n(M['acled_events'])} events and {n(M['acled_fat'])} reported fatalities across "
        f"{M['acled_admin1']} provinces in {M['acled_weeks']} weeks. This chapter describes how the conflict system evolved "
        "and tests hypotheses H1 and H2.")
    d.fig("f5_1_annual", "Annual events and reported fatalities, 2015-2026 (2026 = 26 weeks)")
    d.p(f"Event volume peaked in 2024 ({n(M['yr_2024_events'])} events), driven by the Gaza war, the Israel-Hezbollah escalation "
        f"and the Red Sea campaign. In only 26 weeks, 2026 has already reached {n(M['yr_2026_events'])} events, and 2026 fatalities are "
        "the highest since 2019. Part of that fatality count comes from ACLED's coding of the January 2026 unrest in Iran: "
        f"{n(M['iran_riot_fat_jan26'])} fatalities in the single week of 3 January 2026, almost all coded as riots and protests. The rest comes from the war that began on 28 February.")
    d.fig("f5_2_eventmix", "Share of event types by year")
    d.p("Explosions/remote violence (air and drone strikes, shelling, missiles, IEDs) is the largest event type in most years. "
        "Its share rises sharply in years of inter-state war: 44.7 per cent in 2024 and 38.0 per cent in 2026. In between, protests and strategic developments "
        "dominate. The pattern for 2026 is clear: stand-off strikes (air/drone strike plus shelling/missile) made up "
        "<b>84 per cent</b> of all political violence recorded between 28 February and 10 April 2026.")
    d.fig("f5_3_heatmap", "Political-violence events by country and year (log colour scale)", width=84)
    d.p("The heat map shows the conflict moving across the region. Syria and Iraq dominated from 2015 to 2018. Palestine, Israel and Lebanon rose "
        "after 2023. In 2026 Iran and the GCC states, which had previously seen little political violence, turned dark. Bahrain, Kuwait, the UAE, "
        "Qatar and Oman record more political violence in the first half of 2026 than in the previous decade.")
    d.section("5.1", "Regime Shifts (H1)")
    d.fig("f5_4_changepoints", "Weekly political violence with PELT change-points (orange = regime mean)")
    d.table(T("t5_2_regimes"), "Conflict regimes detected by PELT")
    d.p("Without being told any dates, PELT placed change-points on <b>7 October 2023</b> (the Hamas attack on Israel and the "
        "start of the Gaza war), <b>21 September 2024</b> (the Israel-Hezbollah escalation), <b>30 November 2024</b> (the collapse of the Assad "
        "government followed shortly after) and <b>28 February 2026</b> (the regional war), with a de-escalation break on "
        f"<b>11 April 2026</b>. Weekly political violence averaged {M['pv_war_wk']:,.0f} events in the war regime against "
        f"{M['pv_base_wk']:,.0f} in the preceding 52 weeks, a {M['pv_war_ratio']:.1f}-fold rise (Mann-Whitney U, "
        f"p = {M['mw_p']:.1e}). After the April break, violence settled at about {M['pv_post_wk']:,.0f} events a week, "
        "still above the pre-war level. <b>H1 is supported.</b>")
    d.section("5.2", "Stand-off Warfare and the Spill-over to the Energy Coast (H2)")
    d.fig("f5_5_drone_share", "Share of stand-off strikes (air/drone strike, shelling/missile) in political violence, quarterly")
    d.p("Stand-off strikes are not trending steadily upwards. Their share <i>jumps</i> when an inter-state war begins "
        f"(linear trend p = {M['drone_share_p']:.2f}), reaching {M['drone_share_last']:.0f} per cent in Q1-2026. The share of stand-off "
        "strikes therefore works as a signature of war: a rise in it is an early-warning signal that ranges, and with them "
        "threats to shipping and energy infrastructure, are about to extend.")
    d.fig("f5_6_gcc", "Weekly political violence inside the GCC states, June 2025 - June 2026")
    d.p(f"Before the war the six GCC states together recorded about {M['gcc_pre_wk']:.1f} political-violence events a week. In "
        f"the six weeks from 28 February 2026 this rose to {M['gcc_war_wk']:.1f} a week, a <b>{M['gcc_multiplier']:.0f}-fold</b> increase. The UAE, "
        "Kuwait, Bahrain and Qatar, which host the region's export terminals, refineries and LNG trains, were struck directly.")
    d.fig("f5_7_war_map", "Geography of political violence, 28 February - 10 April 2026", width=81)
    d.table(T("t5_3_top_admin1_war"), "Top provinces by political-violence events, 28 Feb - 10 Apr 2026", small=True)
    d.p(f"Hormozgan, the Iranian province on the northern shore of the Strait of Hormuz, recorded {229} events and 215 fatalities "
        "in six weeks. Bushehr, Khuzestan (the oil province at the head of the Gulf) and Fars were also among the most affected Iranian "
        "provinces. The fighting reached the shoreline of the world's most important energy chokepoint.")
    d.fig("f5_8_maritime", "Conflict at sea: ACLED at-sea events by year and by sub-type")
    d.p(f"ACLED recorded {M['maritime_2022']} at-sea events in 2022, {M['maritime_2023']} in 2023, {M['maritime_2024']} in 2024 "
        f"and {M['maritime_2025']} in 2025, and already {M['maritime_2026']} in the first half of 2026. The dominant sub-types, "
        "'disrupted weapons use' (missiles and drones intercepted over the sea) and shelling/missile attacks, are those of an "
        "anti-shipping campaign. <b>H2 is supported</b> (see also Section 6.1).")

    # ================================================================== 6 CCII
    d.chapter("Chokepoint Conflict Intensity and Disruption Survival")
    d.section("6.1", "The Chokepoint Conflict Intensity Index (CCII)")
    d.p("Each theatre's threat to shipping is measured where it appears in the data. Weekly political-violence events are "
        "weighted 1.5 for stand-off strikes (the type of attack that reaches ships and terminals) and 1.0 otherwise:")
    d.bullets([
        "<b>Hormuz (littoral)</b>: events in ADMIN1 units within 500 km of the strait (coastal Iran, UAE, Oman, Qatar).",
        "<b>Red Sea / Arabian Sea (at sea)</b>: ACLED's at-sea 'North Indian Ocean' events, i.e. the Houthi anti-shipping campaign.",
        "<b>East Med (at sea)</b> and <b>Black Sea (at sea)</b>: ACLED's at-sea events for those waters.",
    ])
    d.p("A theatre is <i>disrupted</i> in a week when its index is above its own threshold, set at the 2015-2022 baseline mean plus 3 SD "
        "(minimum 3 weighted events).")
    d.fig("f6_1_ccii", "Chokepoint Conflict Intensity Index by theatre, 2015-2026")
    d.fig("f6_5_offshore", "Red Sea theatre: stand-off strikes on the Yemeni littoral versus violence at sea")
    d.p(f"<b>The Red Sea threat moved offshore.</b> Stand-off strikes on land within 500 km of Bab-el-Mandeb fell from "
        f"{n(M['yem_land_2019'])} in 2019 to {n(M['yem_land_2025'])} in 2025 as Yemen's civil war froze. Over the same years "
        f"violence at sea rose from {M['sea_2022']} events in 2022 to {M['sea_2024']} in 2024. An index built on land violence "
        "alone would have shown the Red Sea getting <i>safer</i> just as it became the most dangerous waterway in the world for merchant shipping. "
        f"During the 2026 war the Hormuz littoral index averaged <b>{M['hormuz_war_mult']:.0f} times</b> its 2015-2022 "
        f"baseline, and the Red Sea at-sea index averaged {M['redsea_2024_mult']:.0f} times its baseline from mid-November 2023 to December 2024.")
    d.fig("f6_2_ccii_z", "Theatre stress relative to its disruption threshold (4-week rolling mean, symmetric-log scale)")
    d.section("6.2", "Forecasting the Hormuz Index")
    d.table(T("t6_1_backtest"), "12-week hold-out back-test of forecasting models (Hormuz littoral index)")
    d.p("ARIMA(1,0,1) on the log-transformed index roughly halved the back-test error of the naive forecast and beat "
        "damped-trend exponential smoothing. It was refitted on all data and projected 13 weeks ahead, to the end of September 2026.")
    d.fig("f6_3_forecast", "Hormuz CCII: observed values and 13-week ARIMA forecast with 80 per cent interval")
    d.p(f"The central forecast falls back towards {M['fc_end_mean']:.1f} weighted events a week by the end of September "
        f"(80 per cent interval {M['fc_end_lo']:.1f}-{M['fc_end_hi']:.1f}), below the disruption threshold of {M['hormuz_thr']:.1f}. "
        f"However, in 4,000 simulated paths from the fitted model, <b>{pct(M['fc_prob_above_thr'])}</b> cross the threshold in at least "
        "one of the 13 weeks. The Hormuz littoral has not returned to its pre-war calm. Flare-ups should be treated as the "
        "base case through the third quarter of 2026, not as a tail risk.")
    d.section("6.3", "How Long Do Disruptions Last? Survival Analysis")
    d.p(f"Applying the threshold rule to each theatre produced {M['ep_n']} disruption episodes. One of them, on the Hormuz littoral, "
        "was still under way at the end of the data and is right-censored.")
    d.fig("f6_4_km", "Kaplan-Meier survival of disruption episodes; red lines mark India's strategic oil cover")
    d.table(T("t6_3_km_summary"), "Disruption episodes by theatre")
    d.p(f"Across the {M['ep_n']} episodes, the median disruption lasts {M['ep_median_wk']:.1f} weeks, the mean "
        f"{M['ep_mean_wk']:.1f} weeks and the longest {M['ep_max_wk']} weeks, so the distribution is heavy-tailed. "
        f"The probability that an episode outlasts <b>9.5 days</b>, India's strategic petroleum reserve cover, is "
        f"<b>{pct(M['km_p_gt_spr'])}</b>. The probability that it outlasts <b>74 days</b>, the total national cover including refiners' "
        f"stocks, is <b>{pct(M['km_p_gt_74d'])}</b>. Red Sea episodes last longer than Hormuz episodes (median 4.0 against 2.0 weeks; "
        f"log-rank &chi;² = {M['logrank_chi2']:.2f}, p = {M['logrank_p']:.3f}).")
    cox = T("t6_4_cox").rename(columns={"coef": "Coefficient"})
    cox["Covariate"] = cox.Covariate.str.replace("chokepoint_", "Theatre: ").str.replace("post2023", "Episode began after Oct 2023")
    d.table(cox, "Cox proportional-hazards model of the hazard of a disruption ending (reference: Black Sea)")
    d.p(f"A hazard ratio below 1 means an episode is <i>less likely to end</i>, i.e. it lasts longer. Episodes that began after "
        f"October 2023 have a hazard ratio of {M['cox_post2023_hr']:.2f}: they are more persistent, though with only 32 "
        f"episodes the estimate is not significant at the 5 per cent level (p = {M['cox_post2023_p']:.2f}). <b>H6 is supported</b>: "
        "disruptions are heavy-tailed and most of them outlast India's strategic reserve.")

    # ================================================================== 7 SAR / AIS DARK
    d.chapter("Maritime Traffic and AIS Dark Zones")
    d.p(f"This chapter analyses {n(M['sar_rows'])} Sentinel-1 vessel detections from 1-14 March 2026, the first two "
        "weeks of the war, and tests hypotheses H3 and H4.")
    d.fig("f7_1_global_map", "Sentinel-1 vessel detections, 1-14 March 2026 (blue = AIS-matched, orange = AIS-dark)")
    d.section("7.1", "Where Are Ships Dark? (H3)")
    d.fig("f7_2_dark_by_region", "AIS-dark share by sea region, all vessels and large vessels, with 95 per cent Wilson intervals")
    rt = T("t7_1_dark_by_region")
    for c in ["Dark share (all)", "Dark share (large)", "CI low", "CI high"]:
        rt[c] = rt[c].map(lambda v: f"{v * 100:.1f}%")
    d.table(rt, "AIS-dark share by region (large = hull length &ge; 100 m)", small=True)
    d.p("Looking at all ships gives a misleading picture, because small craft are dark almost everywhere. Once the comparison is "
        "restricted to <b>large ships (&ge;100 m)</b>, which carry AIS by regulation, the war zones stand out: <b>Strait of Hormuz "
        f"{pct(M['hormuz_large_dark'])}</b>, Persian Gulf {pct(M['pg_large_dark'])}, Gulf of Oman {pct(M['goo_large_dark'])}, "
        f"Black Sea {pct(M['black_large_dark'])}. Every region at peace lies between about 7 and 17 per cent, and NW Europe is lowest at 8 per cent. "
        f"Large ships in war zones are dark in {pct(M['large_conflict_dark'])} of cases against {pct(M['large_rest_dark'])} elsewhere: "
        f"a <b>relative risk of {M['large_rr']:.1f}</b> and an <b>odds ratio of {M['large_or']:.1f}</b> "
        f"(&chi;² = {M['chi2']:,.0f}, p &lt; 10<sup>-300</sup>). <b>H3 is strongly supported.</b>")
    d.p("The Black Sea result is independent corroboration. It lies outside the ACLED Middle-East data, and it is the other theatre named in the Datathon problem statement. "
        f"The Russia-Ukraine war produces the same signature: {pct(M['black_large_dark'])} of large ships dark, about four times the peacetime norm.")
    d.p(f"The Red Sea shows a different effect: only {pct(M['redsea_large_dark'])} of large ships are dark, and just 54 detections were made in "
        "Bab-el-Mandeb in two weeks. In the Red Sea, ships do not go dark in the war zone. <b>They stay away</b>. "
        "The Gulf has no route around it, so ships that must load there go dark instead. The two chokepoints show the two responses of shipping to conflict: "
        "diversion where a detour exists, blinding where it does not. These are the two dominant responses; Section 7.10 shows they are two cells of "
        "a fuller four-signature typology.")
    d.html_fig(IG.blinding_vs_diversion(M), "The two dominant responses of shipping to conflict: blinding versus diversion (infographic; full typology in Figure 7.13)")
    d.fig("f7_3_size_zone", "AIS-dark share by vessel size class and zone")
    d.p("In peaceful waters darkness falls steadily with size, from 72 per cent of craft under 25 m to 8 per cent of ships over 200 m. In the Gulf war zone it "
        "hardly falls at all: ships over 200 m, which is VLCC and LNG-carrier size, are dark 60 per cent of the time. <b>In a war zone, size no longer predicts visibility.</b>")
    d.section("7.2", "Statistically Significant Dark Hot Spots (H4)")
    d.fig("f7_4_gulf_hotspots", "Dark share and Getis-Ord Gi* hot spots, ships &ge; 60 m, India's western approaches (0.5&deg; cells)")
    d.p(f"Of {M['gulf_cells']} half-degree cells with enough ships in the Gulf-Arabian Sea window, <b>{M['gulf_hot_cells']} are "
        "significant dark hot spots</b> (Gi* &gt; 1.96). They form one contiguous belt from Qatar across the UAE coast and Hormuz into the "
        "Gulf of Oman. The north-western Gulf (Kuwait, Iraq, the Saudi coast) and India's west coast are <b>cold spots</b>: large ships there stay visible.")
    d.fig("f7_5_global_hotspots", "Global Gi* hot spots of AIS-dark ships &ge; 60 m (1&deg; cells)")
    d.table(T("t7_3_hotspot_cells").rename(columns={"region": "Region"}), "Significant dark hot-spot cells (1&deg;) by region", small=True)
    d.p(f"Worldwide, {M['global_hot_cells']} of {n(M['global_cells'])} one-degree cells are dark hot spots. Relative to the area "
        "of each region, the Persian Gulf, Gulf of Oman and Black Sea are the densest. Hot spots elsewhere, in the South China Sea, Southern Indian Ocean "
        "and Pacific, mark distant-water fishing grounds where small and medium craft routinely run without AIS [5]. <b>H4 is supported.</b>")
    d.section("7.3", "Where Do Dark Ships Gather? DBSCAN Clusters")
    d.fig("f7_6_dbscan", f"DBSCAN clusters of AIS-dark ships &ge; 100 m (numbers = rank in Table {d.pfx}.{d.tab_no + 1})")
    cl = T("t7_4_dark_clusters").drop(columns=["lat", "lon"])
    cl["Dark share of large ships within 30 km"] = cl["Dark share of large ships within 30 km"].map(lambda v: f"{v * 100:.0f}%")
    d.table(cl, "Largest clusters of dark ships &ge; 100 m", small=True)
    d.p(f"DBSCAN found {M['n_clusters']} clusters. The two largest are off <b>Dubai/Jebel Ali ({n(M['top_cluster_n'])} dark large ships; "
        f"{pct(M['top_cluster_share'])} of all large ships there dark)</b> and the <b>Fujairah/Khor Fakkan anchorage</b>, the "
        "main bunkering and waiting area outside Hormuz. Together with the Hormuz and Ras Laffan clusters, they are fleets of tankers and gas "
        "carriers waiting at anchor with AIS off. That is the physical form of a supply chain on hold. The Novorossiysk/Kerch "
        "clusters are the Black Sea equivalent. The Kolkata/Haldia cluster (44 per cent dark) is the only large-ship cluster in India's own waters "
        "and is flagged for follow-up. The single-day Tokyo Bay cluster is most likely an AIS-matching gap and is treated as an artefact.")
    d.section("7.4", "The Daily Picture in the Gulf")
    d.fig("f7_7_gulf_daily", "Gulf war zone: detections per SAR scene and share AIS-dark, 1-14 March 2026")
    d.p(f"Over the first two weeks of the war, darkness in the Gulf <b>rose</b> from {pct(M['gulf_dark_first3'])} of detections in the "
        f"first three imaged days to {pct(M['gulf_dark_last3'])} in the last three (Spearman &rho; = {M['gulf_daily_trend_rho']:.2f}, "
        f"p = {M['gulf_daily_trend_p']:.3f}). Two days (6 and 12 March) had very few detections per scene, and their shares should be read "
        "with caution. The trend holds with them removed.")
    d.section("7.5", "Who Is Sailing? Flag States of Visible Ships")
    d.fig("f7_8_flags", "Registry class of AIS-visible large ships by zone (MMSI MID decode)")
    d.table(T("t7_6_top_flags_gulf"), "Top flag states of visible large ships, Gulf war zone against rest of world", small=True)
    d.p(f"Flags of convenience make up about half of visible large ships everywhere, so they do not distinguish the war zones. What does distinguish them is "
        f"<b>shadow-fleet-associated registries</b> (Gabon, Cameroon, Comoros, Sierra Leone, Togo, Cook Islands, Palau and similar): "
        f"{M['flag_gulf_shadow']:.1f} per cent of visible large ships in the Gulf and {M['flag_black_shadow']:.1f} per cent in the Black Sea, against "
        f"{M['flag_world_shadow']:.1f} per cent elsewhere. Iranian-flagged ships make up 6.9 per cent of visible large ships in the Gulf against 0.1 per cent worldwide. "
        "The ships still transmitting in the war zone lean towards registries with weak oversight, which adds to the identity problem.")
    d.section("7.6", "India's Maritime Neighbourhood")
    d.fig("f7_10_india_seas", "Arabian Sea and Bay of Bengal: AIS-matched, small dark and large dark detections", width=84)
    d.p(f"India's seas have the highest overall dark shares in the dataset (Arabian Sea {pct(M['arab_all_dark'])}, Bay of Bengal "
        f"{pct(M['bob_all_dark'])}). This is <b>not</b> a conflict signal: {pct(M['india_seas_small_dark_share'])} of craft under 40 m "
        f"are dark, and {pct(M['india_seas_fishing_share_dark'])} of dark detections score as fishing vessels. "
        f"Large ships off India are visible (Arabian Sea {pct(M['arab_large_dark'])} dark, Bay of Bengal {pct(M['bob_large_dark'])}). The "
        "security point is that India's near seas contain thousands of small, uncooperative craft, the same class of craft used in the "
        "26/11 Mumbai attack. The domestic maritime picture depends on non-AIS sensing.")
    d.section("7.7", "Identity Integrity")
    d.table(T("t7_7_identity"), "Indicators of AIS identity anomalies", small=True)
    d.p(f"Beyond darkness, the data show {n(M['sar_mmsi_malformed'])} malformed MMSIs, {M['placeholders']} placeholder identities "
        f"(e.g. 200000000, 412000000) and {M['clones']} cases of one MMSI appearing at two places that would need speeds above "
        "50 knots, i.e. cloned or spoofed identities. These counts are small but not negligible, and they show that an AIS match alone does not "
        "confirm a ship's identity.")

    d.section("7.8", "Did the Ships Leave, or Stop Identifying Themselves?")
    d.p("A fall in AIS-visible traffic has two possible causes that demand opposite responses. If the hulls have gone, the problem is a "
        "volume shock, answered by alternative sourcing and routing. If the hulls are still there but silent, the problem is identification, "
        "answered by independent surveillance, escort and insurance. Radar separates the two. The comparison below uses only the sea area that "
        "two passes over the Strait of Hormuz both imaged, so coverage cannot explain the difference.")
    d.fig("f11_1_presence_identity", "Presence vs identity: big hulls seen by radar and those transmitting AIS, same sea area, 4 and 12 March 2026")
    d.table(T("t11_1_presence_identity"), "Presence vs identity on a common footprint, Strait of Hormuz and approaches", small=True)
    d.p(f"An AIS-based count would report shipping down <b>{abs(M['pi_lit_chg'])}%</b> ({M['pi_lit_1']} to {M['pi_lit_2']} transmitting hulls). "
        f"Radar shows the physical fleet down only {abs(M['pi_radar_chg'])}% ({M['pi_radar_1']} to {M['pi_radar_2']}), a fall similar to that of small "
        f"craft ({M['pi_small_chg']}%), which suggests part of it reflects imaging conditions. Meanwhile the number of dark big hulls did not fall at all "
        f"({M['pi_dark_1']} to {M['pi_dark_2']}), and by 12 March {M['pi_dark_share_2']}% of the big hulls in the strait were silent. "
        "<b>AIS-derived traffic counts overstated the collapse of shipping and understated the collapse of the maritime picture.</b>")
    d.p(f"<b>Had the ships stopped?</b> A ship making even five knots cannot be imaged in the same 100 m square on two different days; a ship at "
        f"anchor can. In Hormuz and the Persian Gulf <b>{M['stasis_dark']:.1f}%</b> of dark big hulls had another detection within 100 m on a different "
        f"day, against a crowding null of {st_null(M)}% (z = {M['stasis_dark_z']}); for transmitting hulls the excess was smaller (z = {M['stasis_lit_z']}). "
        f"In the Malacca Strait and the North Sea the figure for dark hulls is about zero. At 400 m, <b>{M['held_400m']}</b> dark big-hull detections in "
        "the Gulf were held in place. Much of the dark fleet was not running the strait with transponders off: it had stopped, and then could not "
        "be identified.")
    d.table(T("t11_2_stasis"), "Stasis index: share of hulls re-detected within 100 m on a different day, against a crowding null", small=True)
    d.section("7.9", "Who Kept Transmitting?")
    d.fig("f11_2_flag_shift", "Flag mix of the big hulls still transmitting AIS in the Gulf, week 1 against week 2")
    d.p(f"The flag of a dark ship cannot be read, but the flag of the shrinking population that kept transmitting can. Gulf-state flags "
        f"(Iran, UAE, Saudi Arabia, Qatar, Bahrain, Kuwait, Iraq, Oman) rose from <b>{M['flag_littoral_1']:.0f}% to {M['flag_littoral_2']:.0f}%</b> of the "
        f"lit fleet between the first and second week (chi-square p = {M['flag_p']:.3f}), while the major open registries (Liberia, Marshall Islands, "
        f"Panama) fell only slightly ({M['flag_open_1']:.0f}% to {M['flag_open_2']:.0f}%). <b>Identity was protective for local ships and dangerous for "
        "outsiders.</b> Shadow-fleet-associated registries did not change their share materially, so the dark population is best read as mainstream "
        "international tonnage, not mainly a sanctions-evasion fleet.")
    d.section("7.10", "Four Signatures of a Sea Line Under Stress")
    d.p("Chapter 7 so far points to a rule. A master switches off AIS when two conditions hold together: being identified is dangerous, "
        "and not sailing is not an option. The two conditions give four observable signatures, each with a different supply-chain consequence. "
        "Each sea was assigned by a rule declared in advance: SDR above 40% (concealment); 25-40% and flat (attrition/frozen); near baseline "
        "on an attacked route with a detour (evacuation); at or below baseline despite heavy conflict nearby (deterrence/compliance).")
    d.html_fig(IG.signatures(M, T("t11_6_signatures")), "The four signatures of a sea line under stress (infographic)")
    d.table(T("t11_6_signatures"), "Signature assignment by rule", small=True)
    d.p(f"The East Mediterranean is the control that proves the instrument measures behaviour: {M['sdr_baseline']:.0f}% is the peaceful-sea "
        "baseline, and the East Med and Suez approaches sit at or below it despite the heaviest violence in the dataset within 300 km, because "
        "a credible authority enforces reporting there. <b>The same war produced four different behaviours at sea; the difference is not the "
        "intensity of the fighting but whether identity is dangerous and whether the route can be given up.</b>")

    # ================================================================== 8 PREDICTIVE MODEL
    d.chapter("Predicting AIS Dark Spots")
    d.p(f"The Datathon problem statement asks participants to <i>predict</i> AIS dark spots. A model was trained on "
        f"{n(M['model_n'])} detections of ships &ge; 40 m (the AIS-carrying fleet; base dark rate {pct(M['model_base_rate'], 1)}). "
        "It uses five features that describe the ship and its conflict geography, and it deliberately excludes latitude and longitude "
        "so that it cannot simply memorise where the dark ships are.")
    lt = T("t8_1_logit")
    d.table(lt, "Logistic regression: odds ratios per 1 SD of each feature (all 62,624 ships &ge; 40 m)")
    d.p(f"Holding size and type constant, each 1-SD increase in (log) distance from the nearest active conflict province lowers "
        f"the odds of darkness to {M['or_dist']:.2f} times. The raw event count within 500 km adds nothing once distance is known. "
        "<i>Proximity</i> to the fighting matters; the <i>volume</i> of fighting does not.")
    mt = T("t8_2_model_cv")
    d.table(mt, "Model skill, leave-one-region-out cross-validation", small=True)
    d.fig("f8_1_model", "ROC curves (leave-one-region-out) and permutation importance")
    d.p(f"Evaluated only on sea regions it had never seen, the gradient-boosted model reaches <b>ROC-AUC {M['auc_gbt']:.2f}</b> and "
        f"<b>PR-AUC {M['prauc_gbt']:.2f}</b>, almost twice the {M['model_base_rate']:.2f} a random model would score. Ordinary random "
        f"cross-validation would have reported AUC {M['auc_gbt_random']:.2f}. That inflation from spatial leakage is exactly what "
        "Roberts et al. warn against [14], and the lower, honest figure is the one relied on here. <b>H5 is supported</b>: conflict geography "
        "carries real, transferable information about where ships will go dark.")
    d.fig("f8_2_pdp", "Model response: predicted darkness against distance from active conflict")
    d.fig("f8_3_risk_surface", "Predicted AIS dark-spot surface for a 180 m merchant ship, early-March-2026 conflict picture")
    pr = T("t8_3_poi_risk")
    pr[pr.columns[1]] = pr[pr.columns[1]].map(lambda v: f"{v * 100:.0f}%")
    d.table(pr, "Predicted probability that a 180 m merchant ship is AIS-dark at points of interest to India")
    d.p("The model's surface reproduces the observed belt of darkness along Hormuz and the UAE coast and a secondary area around "
        "Bab-el-Mandeb and the Gulf of Aden. It also gives a <i>transferable</i> rule. Given a new conflict picture, such as a future escalation near "
        "Chabahar or the Makran coast, the same model can be re-run to predict where the cooperative maritime picture will fail "
        "before any satellite pass confirms it.")

    # ================================================================== 9 ECONOMIC TRANSMISSION (OPEN DATA)
    d.chapter("Economic and Shipping Transmission: Evidence from Open-Source Data")
    d.p("The Datathon datasets measure conflict and ship behaviour. To measure the <i>economic</i> impact on supply chains, and to test "
        "the study's early-warning indicators against events after the data ended, four open-source datasets were added, as the General "
        "Instructions encourage [3]. The questions are simple: did the conflicts move the oil price and the rupee, does conflict intensity "
        "warn of price moves in advance, what did the 2026 war cost India, and did the June 2026 early-warning call hold?")
    d.section("9.1", "Open-Source Data Used")
    d.table(pd.DataFrame([
        ("Brent and WTI crude spot prices (daily)", "U.S. EIA, via the open 'datasets/oil-prices' repository [21]", f"1987 - {M['brent_last_date']}", "Event study, war premium, out-of-sample test"),
        ("INR per US$ (daily)", "U.S. Federal Reserve H.10, via 'datasets/exchange-rates' [22]", "1973 - 18 Sep 2026", "Rupee pass-through"),
        ("Oil consumption and production by country (annual)", "Energy Institute Statistical Review, via Our World in Data [23]", "1965 - 2024", "India's import dependence and volume"),
        ("World ports (point layer)", "Natural Earth 10 m cultural vectors [24]", "current", "Theatre infographic"),
        ("Daily transits at 28 world chokepoints (AIS-based)", "IMF PortWatch [26]", "2019 - 16 Aug 2026", "Movement layer, shipping-disruption durations"),
        ("News and official statements (verified)", "PIB, AIR, The National, Al Jazeera, CNBC [27-31]", "Mar - Sep 2026", "Chronology, cross-checks"),
    ], columns=["Dataset", "Source", "Coverage", "Used for"]), "Open-source datasets added to the study", small=True)
    d.section("9.2", "Oil Price and Chokepoint Conflict")
    d.fig("f9o_1_brent_timeline", "Brent crude (daily) against the chokepoint conflict indices, 2022 - September 2026")
    d.p(f"Brent closed at <b>US${M['brent_prewar']:.0f}</b> on the last trading day before the war. It passed US$100 within two weeks and "
        f"was <b>{M['brent_3wk_rise']:.0f}% higher</b> by 20 March. Its peak so far is <b>US${M['brent_war_peak']:.0f} ({M['brent_war_peak_date']})</b>. "
        f"Realised volatility almost tripled, from {M['vol_pre']:.0f}% (annualised, pre-war year) to {M['vol_war']:.0f}% in March-April 2026.")
    d.section("9.3", "Event Study: Four Conflict Shocks")
    d.fig("f9o_2_event_study", "Brent response to four Middle-East conflict shocks (per cent change from the last close before the event)")
    d.table(T("t9o_1_event_study"), "Event study results", small=True)
    d.p(f"The four shocks behaved very differently. The Gaza war and the June 2025 Israel-Iran strikes produced short spikes (+7% and +14%) that "
        f"faded within a month. The Red Sea campaign <i>lowered</i> the price (-5% after 20 days): ships diverted, but no oil was lost. The 2026 war, "
        f"which reached the Hormuz littoral, produced a sustained shock of <b>+{M['ev_war_20']:.0f}% after 20 days and +{M['ev_war_peak']:.0f}% at the peak</b>. "
        "This independent market evidence confirms the 'blinding versus diversion' distinction of Chapter 7. Where a detour exists the cost appears as freight and time. "
        "Where none exists it appears as a price shock to every importer.")
    d.section("9.4", "Does Conflict Intensity Lead the Oil Price?")
    d.table(T("t9o_2_granger"), "Granger-causality tests, weekly, 2015 - June 2026", small=True)
    d.p("It does not. Weekly conflict intensity does not Granger-cause weekly oil returns at any lag tested (p &gt; 0.4), and the "
        "contemporaneous correlation is close to zero. Oil markets react to the <i>event</i> within days, and ordinary weekly fluctuations in "
        "violence carry no price information. The practical point is that <b>the market is not an early-warning system</b>: by the time the price moves, "
        "the disruption has begun. Warning must come from the conflict and ship-behaviour indicators, as Section 9.8 shows.")
    d.section("9.5", "The Rupee")
    d.fig("f9o_3_rupee", "INR per US$ since 2025, and weekly pass-through from Brent to the rupee (2015-2026)")
    d.p(f"The rupee weakened from {M['fx_base']:.2f} (pre-war average) to {M['fx_war']:.2f} (war-period average) per dollar, and stood at "
        f"{M['fx_last']:.2f} in mid-September, <b>{M['fx_dep_pct']:+.1f}%</b> since the war began. Week-to-week pass-through from oil is statistically nil "
        f"(beta = {M['passthrough_beta']:.3f}, p = {M['passthrough_p']:.2f}), consistent with central-bank smoothing. The depreciation is gradual and "
        "cumulative, not sudden, and it compounds the dollar oil shock.")
    d.section("9.6", "India's Structural Exposure")
    d.fig("f9o_4_india_dependence", "India's oil consumption, production and import dependence, 1990-2024")
    d.p(f"From the Energy Institute data, India imported <b>{M['india_dep']:.1f}%</b> of the oil it consumed in {M['india_dep_year']}, up from "
        f"{M['india_dep_first']:.0f}% in {M['india_dep_first_year']}. China's figure is {M['dep_china']:.0f}%, while Japan and Korea import almost all of theirs. "
        f"India's net import requirement is about <b>{M['india_bpd']:.2f} million barrels a day</b>. Dependence is rising, not falling, so each new "
        "chokepoint shock costs India more than the last.")
    d.section("9.7", "The War Premium on India's Import Bill")
    d.table(T("t9o_3_war_premium"), "Estimated war premium on India's oil import bill (open-source data)", small=True,
            note="Volume from Energy Institute net imports (1 barrel = 1.70 MWh); prices from EIA Brent; exchange rate from Federal Reserve H.10. "
                 "Order-of-magnitude estimate: actual crude purchase prices, discounts and product trade differ.")
    d.p(f"Over the {M['war_days']} days from 1 March to {M['brent_last_date']}, the war added roughly <b>US${M['extra_bill_usd_bn']:.0f} billion "
        f"(about Rs {M['extra_bill_inr_lakh_cr']:.1f} lakh crore including the rupee effect)</b> to India's oil import bill. Every US$10 a barrel "
        f"sustained for a year costs about US${M['per10_usd_bn']:.1f} billion. This is the fiscal channel through which the war reaches the defence "
        "budget, including its POL and revenue heads.")
    d.table(T("t11_7_defence_budget"), "The oil premium in defence terms", small=True,
            note=f"Monthly defence budget from the 2026-27 MoD allocation of Rs {M['def_budget_lakh_cr']} lakh crore at the March 2026 exchange rate "
                 f"(US$ {M['def_monthly_usd_bn']:.2f} bn per month). Premium = monthly Brent average minus the February average.")
    d.p(f"In the unit a defence audience uses: in March 2026 the extra oil bill was <b>{M['def_ratio_mar_lo'] * 100:.0f}-{M['def_ratio_mar_hi'] * 100:.0f}% of the "
        f"entire monthly cost of the Armed Forces</b>; in April, at US${M['brent_apr']:.0f} Brent, it reached {M['def_ratio_apr_hi'] * 100:.0f}% on the "
        "crude-import basis. The Armed Forces cannot prevent this cost, but they are best placed to see it coming and to say what kind of event it is.")
    d.section("9.8", "Out-of-Sample Test of the Early-Warning Call")
    d.p(f"The conflict data end on 27 June 2026. At that date the I&amp;W matrix (Chapter 14) read <b>{M['iw_red']} Red and {M['iw_amber']} Amber</b>, "
        f"and its recommendation was to hold buffers and not release reserves. The oil market said the opposite: Brent had fallen back to "
        f"<b>US${M['brent_at_cut']:.0f}</b>, its pre-war level. After the data ended, Brent rose <b>{M['brent_oos_change']:+.0f}%</b> to "
        f"<b>US${M['brent_last']:.0f}</b> by {M['brent_last_date']}. The indicators built in this study, from open conflict and satellite data, "
        "called a continuing crisis that the market price did not. This is a single test, but a demanding one, because the outcome was not "
        "available to the analysis. IMF PortWatch shows why the market was fooled: in late June Hormuz transits briefly recovered to about "
        "a third of normal (a false dawn), then fell back to about 5% of normal by August [26].")
    d.section("9.9", "Movement: Chokepoint Transits (IMF PortWatch)")
    d.p("The CDM satellite data cover a fortnight. IMF PortWatch counts ships crossing each of 28 world chokepoints every day from AIS, "
        "and extends the picture to mid-August 2026. It measures the third layer the study needs: <b>movement</b>.")
    d.fig("f12_1_hormuz_transits", "Strait of Hormuz daily transits, September 2025 - August 2026 (IMF PortWatch)")
    d.p(f"Transits fell from a 2025 baseline of <b>{M['pw_base']:.0f} a day</b> to <b>{M['pw_post']:.1f}</b> after 1 March, a fall of "
        f"<b>{M['pw_drop']:.0f}%</b> (tankers {M['pw_tank_drop']:.0f}%). During the satellite window (1-14 March) the average was {M['pw_sar_win']:.1f} a day "
        f"and on 4 March it was <b>{M['pw_zero_4mar']}</b>. In the last 30 days of the record traffic was {M['pw_last30_pct']:.0f}% of normal.")
    d.fig("f12_2_chokepoints", "Change in transits at 28 world chokepoints, March-August 2026 against March-August 2025")
    d.p(f"Only Hormuz stopped: {M['pw_hormuz_change']:.0f}% against an average of {M['pw_ctrl_change']:+.0f}% at seven control chokepoints "
        "(Malacca, Panama, Taiwan, Korea, Bosporus, Dover, Gibraltar).")
    d.section("9.10", "Presence, Identity and Movement Together")
    d.p(f"On <b>4 March 2026</b> PortWatch recorded <b>{M['pw_zero_4mar']} transits</b> through Hormuz. On the same day Sentinel-1 radar imaged "
        f"<b>{M['pi_radar_1']} big hulls</b> in the strait and its approaches, {M['pi_lit_1']} of them still transmitting AIS. The ships were there "
        "(presence), a growing share had stopped identifying themselves (identity), and almost none were crossing (movement). The stasis "
        "index (Section 7.8) had already shown dark hulls held in place; the transit data confirm it from an independent source. "
        "<b>Three layers, three sources, one conclusion: the fleet was held, silent, inside the Gulf.</b>")
    d.table(pd.DataFrame([
        ("Presence", "Is the hull physically there?", "Sentinel-1 SAR (CDM)", f"{M['pi_radar_1']} big hulls on 4 Mar; two-thirds still present on 12 Mar"),
        ("Identity", "Does it say who it is?", "SAR matched to AIS (CDM)", f"SDR {M['hormuz_large_dark'] * 100:.0f}% at Hormuz vs {M['sdr_baseline']:.0f}% baseline"),
        ("Movement", "Is it crossing, or held?", "IMF PortWatch transits; SAR revisits", f"{M['pw_zero_4mar']} transits on 4 Mar; stasis z = {M['stasis_dark_z']}"),
        ("Throughput", "What cargo reaches India?", "Oil price, import bill (open data)", f"Brent +{M['ev_war_peak']:.0f}% peak; ~US${M['extra_bill_usd_bn']:.0f} bn extra"),
    ], columns=["Layer", "Question", "Source", "Evidence"]), "The four layers of the maritime picture, each measured", small=True)
    d.section("9.11", "Evacuation Confirmed at the Red Sea")
    d.fig("f12_3_evacuation", "Bab-el-Mandeb, Suez and Cape of Good Hope transits, 2023-2026 (IMF PortWatch)")
    d.p(f"The evacuation signature assigned to the Red Sea in Section 7.10 from radar alone is confirmed by movement data: Bab-el-Mandeb transits "
        f"have run <b>{M['bm_drop']:.0f}% below</b> their 2023 level since January 2024, and Cape of Good Hope transits <b>{M['cape_rise']:.0f}% above</b>. "
        "The tonnage left, the ships that remained kept transmitting, and two and a half years later it has not reversed.")
    d.section("9.12", "How Long Do Shipping Disruptions Last?")
    d.fig("f12_4_duration", "Survival of conflict flare-ups (ACLED) against shipping disruptions (IMF PortWatch) at chokepoints")
    d.table(T("t12_2_shipping_disruptions"), "Shipping disruptions at world chokepoints, 2019-2026 (7-day transits below half of the prior-year median)", small=True)
    d.p(f"This is the most important correction the open data make. Conflict flare-ups near chokepoints last a median of {M['ep_median_wk']:.1f} weeks "
        f"(Chapter 6). The <b>shipping disruptions</b> they cause last a median of <b>{M['ship_ep_median']:.0f} days</b>, and <b>{M['ship_p_gt_74'] * 100:.0f}%</b> "
        f"outlast India's 74-day national cover. The Red Sea disruption ran about 22 months; the Hormuz closure had lasted {M['closure_days']} days at the "
        "end of the record and was still in force in September [31]. <b>Fighting flares for weeks; the shipping disruption it causes lasts months.</b>")
    d.section("9.13", "Open-Source Chronology")
    d.table(pd.DataFrame([
        ("28 Feb 2026", "Regional war begins; weekly political violence triples", "ACLED (CDM data)"),
        ("1-4 Mar", f"Hormuz transits collapse from ~{M['pw_base']:.0f}/day to {M['pw_zero_4mar']} on 4 Mar; SAR shows hulls present and going dark", "IMF PortWatch [26]; Sentinel-1 (CDM)"),
        ("11 Mar", "Petroleum Ministry: 70% of India's crude now sourced outside Hormuz, up from 55%", "AIR News [28]"),
        ("18 Mar", "Hundreds of tankers reported holding outside or stranded inside the Gulf", "CNBC [31]"),
        ("23 Mar", "Indian Navy begins Op Urja Suraksha, escorting Indian-flagged energy carriers from the Gulf of Oman", "[29]"),
        ("Late Jun", "Partial reopening: transits recover to about a third of normal; Brent falls to ~US$70", "IMF PortWatch [26]; EIA [21]"),
        ("Jul", "War-risk premiums 3-10% of hull value (from ~0.25%); Bab-el-Mandeb shut again", "The National, Al Jazeera [30]"),
        ("Aug-Sep", f"Hormuz transits ~{M['pw_last30_pct']:.0f}% of normal; strait still closed; Brent US${M['brent_last']:.0f} on {M['brent_last_date']}", "IMF PortWatch [26]; [31]; EIA [21]"),
    ], columns=["Date", "Event", "Source"]), "Chronology of the crisis from open sources", small=True)

    # ================================================================== 10 INFERENCE
    d.chapter("Inference")
    d.p("This chapter brings together the results of Chapters 5 to 9, gives the verdict on each hypothesis and states the "
        "inferences that the impact assessments (Chapters 11-13) and the way forward (Chapter 14) are built on.")
    d.section("10.1", "Key Findings")
    kp = [(f"{M['pv_war_ratio']:.1f}x", "weekly political violence in the 2026 war regime vs the prior year"),
          (f"{M['gcc_multiplier']:.0f}x", "rise in violence inside GCC energy states"),
          (pct(M['hormuz_large_dark']), "large ships AIS-dark in the Strait of Hormuz"),
          (f"{M['large_rr']:.1f}x", "relative risk of darkness for large ships in war zones"),
          (pct(M['km_p_gt_spr']), "disruptions outlasting India's 9.5-day SPR")]
    d.add('<div class="kpis">' + "".join(f'<div class="kpi"><div class="v">{v}</div><div class="l">{l}</div></div>' for v, l in kp) + "</div>")
    F = pd.DataFrame([
        ("F1", "Violence rose 2.9-fold in the 2026 war regime; PELT dated the regime shifts to 7 Oct 2023 and 28 Feb 2026 without being given the dates.", "5.1"),
        ("F2", "84% of war-period violence was stand-off strikes (air, drone, missile, artillery), a sharp jump that marks the onset of inter-state war.", "5.2"),
        ("F3", f"The war reached the energy coast: GCC violence rose {M['gcc_multiplier']:.0f}-fold, the Hormuz littoral index {M['hormuz_war_mult']:.0f}-fold.", "5.2, 6.1"),
        ("F4", "The Red Sea threat moved offshore: land strikes fell ~6-fold while at-sea violence rose ~30-fold; a land-based index would miss it.", "6.1"),
        ("F5", f"Disruptions are heavy-tailed: median {M['ep_median_wk']:.1f} wk, max {M['ep_max_wk']} wk; {pct(M['km_p_gt_spr'])} outlast the SPR, {pct(M['km_p_gt_74d'])} outlast 74 days; Hormuz stays elevated into Q3-2026 ({pct(M['fc_prob_above_thr'])} of simulated paths cross the threshold).", "6.2, 6.3"),
        ("F6", f"Large ships in war zones are {M['large_rr']:.1f}x more likely to be AIS-dark (Hormuz {pct(M['hormuz_large_dark'])}, Black Sea {pct(M['black_large_dark'])}); darkness in the Gulf rose over the first two weeks of the war.", "7.1, 7.4"),
        ("F7", "Blinding where there is no detour (Gulf) and diversion where there is (Red Sea): the two dominant cells of a four-signature typology (F14).", "7.1, 7.10"),
        ("F8", "Dark ships gather at the Dubai/Jebel Ali and Fujairah anchorages: the supply chain is held at anchor with AIS off. Shadow-fleet registries are over-represented among visible ships (~3x), but the dark fleet is mainly mainstream tonnage.", "7.3, 7.5, 7.9"),
        ("F9", "India's near seas are dominated by thousands of small, non-AIS craft; large ships off India remain visible.", "7.6"),
        ("F10", f"Proximity to conflict predicts darkness in unseen regions (ROC-AUC {M['auc_gbt']:.2f}); AIS identity itself is unreliable (clones, placeholders, malformed IDs).", "7.7, 8"),
        ("F11", f"The Hormuz war sent Brent +{M['ev_war_peak']:.0f}% within 40 days and the rupee {M['fx_dep_pct']:+.1f}%; the Red Sea campaign barely moved oil. The war added ~US${M['extra_bill_usd_bn']:.0f} bn to India's oil bill.", "9.2-9.7"),
        ("F12", f"Weekly conflict intensity does not lead oil prices, yet the June I&W call (Red at US${M['brent_at_cut']:.0f} Brent) was followed by a {M['brent_oos_change']:.0f}% rise: the indicators warned where the market did not.", "9.4, 9.8"),
        ("F13", f"AIS counts said Hormuz shipping fell {abs(M['pi_lit_chg'])}%; radar saw the physical fleet fall only {abs(M['pi_radar_chg'])}% and the dark fleet not at all; many dark hulls were held in place (stasis z = {M['stasis_dark_z']}).", "7.8"),
        ("F14", "Four signatures, not one: concealment (Gulf), evacuation (Red Sea), attrition/frozen (Black Sea), compliance (East Med, near-zero darkness beside heavy conflict).", "7.9-7.10"),
        ("F15", f"Movement (IMF PortWatch) confirms the picture: Hormuz transits -{M['pw_drop']:.0f}% with zero on 4 Mar while radar saw {M['pi_radar_1']} hulls; only Hormuz stopped among 28 chokepoints; the Red Sea evacuation has lasted over two years.", "9.9-9.11"),
        ("F16", f"Shipping disruptions last far longer than the fighting: median {M['ship_ep_median']:.0f} days, {M['ship_p_gt_74'] * 100:.0f}% beyond 74 days; the Hormuz closure passed {M['closure_days']} days.", "9.12"),
    ], columns=["#", "Finding", "Section"])
    d.table(F, "Key findings of the study")
    d.section("10.2", "Verdict on the Hypotheses")
    d.table(pd.DataFrame([
        ("H1", "Regime shifts coincide with the 2023 and 2026 wars", f"Supported - change-points on 7 Oct 2023 and 28 Feb 2026; war regime {M['pv_war_ratio']:.1f}x, p = {M['mw_p']:.1e}"),
        ("H2", "War moved to the energy littoral; Red Sea threat moved offshore", f"Supported - GCC {M['gcc_multiplier']:.0f}x, Hormuz littoral {M['hormuz_war_mult']:.0f}x; Yemen land strikes down, at-sea events up"),
        ("H3", "Large ships are more often dark in war zones", f"Strongly supported - RR {M['large_rr']:.1f}, OR {M['large_or']:.1f}, chi-square p &lt; 10<sup>-300</sup>"),
        ("H4", "Darkness forms significant hot spots at conflict chokepoints", f"Supported - {M['gulf_hot_cells']} Gi* hot-spot cells in one belt from Qatar to the Gulf of Oman; largest DBSCAN clusters at Gulf anchorages"),
        ("H5", "Proximity to conflict predicts darkness out-of-region", f"Supported, with moderate skill - ROC-AUC {M['auc_gbt']:.2f}, PR-AUC {M['prauc_gbt']:.2f} against a base rate of {M['model_base_rate']:.2f}"),
        ("H7", "Shocks transmit to oil and rupee; size depends on detour", f"Supported - Hormuz war: Brent +{M['ev_war_peak']:.0f}% peak in 40 days; Red Sea campaign: -5% at +20 days; rupee {M['fx_dep_pct']:+.1f}%. Weekly conflict intensity does not <i>lead</i> prices (Granger p &gt; 0.4)"),
        ("H6", "Disruptions are heavy-tailed and outlast India's oil cover", f"Supported - {pct(M['km_p_gt_spr'])} outlast the SPR, {pct(M['km_p_gt_74d'])} outlast 74 days; post-2023 episodes more persistent (HR {M['cox_post2023_hr']:.2f}, not significant)"),
    ], columns=["#", "Hypothesis", "Verdict and evidence"]), "Verdict on the hypotheses")
    d.section("10.3", "Inferences Drawn")
    d.p("Read together, the findings support six inferences. Each is stated with the findings it rests on.")
    d.bullets([
        "<b>I1 - Conflict at a chokepoint first shows up as a loss of information, and only then as a loss of flow (F6, F8).</b> "
        "Before cargo stops moving, the cooperative maritime picture collapses: large, AIS-obligated ships vanish from it, and tankers "
        "wait at anchor with transponders off. The large-ship dark share is therefore a <i>leading</i> indicator of supply disruption. "
        "It can be measured from space before trade statistics show anything.",
        "<b>I2 - Two conditions decide how shipping responds: whether identity is dangerous and whether a detour exists (F4, F7, F14).</b> Where there is an alternative route, as with the Red Sea and the Cape, "
        "conflict causes diversion: traffic thins and the cost appears as time and freight. Where there is none, as with the Gulf and Hormuz, "
        "conflict causes blinding: ships keep sailing but go dark, and the cost appears as risk. Where a credible authority enforces reporting "
        "(East Med, Suez) identity is protective and ships stay visible; in a long war (Black Sea) a two-fleet pattern freezes in place. "
        "Policy must follow the signature, not the headline.",
        "<b>I3 - Stand-off weapons have removed the distance between a land war and the sea lanes (F2, F3, F4).</b> With 84 per cent of "
        "war-period violence delivered by drones, missiles and artillery, any littoral actor can hold a chokepoint, a terminal or a "
        "logistics node at risk. Distance from the front line no longer protects rear areas.",
        "<b>I4 - Supply disruption is a question of duration, not of spikes (F5).</b> Most episodes are short, but the tail is long and "
        "persistent. Planning for the median episode leaves the force and the nation exposed for most of the expected shortfall. Buffers must be "
        "sized against the survival curve, and the prescriptive model (Chapter 13) shows the point at which extra stock stops paying off.",
        "<b>I5 - Darkness is predictable, so early warning is feasible (F1, F10).</b> Change-points in the conflict series match "
        "real-world turning points, and conflict geography predicts darkness in sea regions the model has never seen. Open "
        "conflict data combined with satellite radar can therefore give warning of where and when the maritime picture will fail.",
        "<b>I6 - AIS identity is necessary but not sufficient (F8, F9, F10).</b> Cloned, placeholder and malformed identities, "
        "shadow-fleet registries and thousands of non-AIS small craft in India's own seas mean that a trustworthy maritime "
        "picture requires independent sensing (SAR, radar) and automated identity checks.",
    ])
    d.section("10.4", "Stress-Testing the Central Inference: Robustness")
    d.p("A judgement that rests on one definition or one threshold is fragile. The war-zone effect on large-ship darkness "
        "was re-estimated under eight alternative specifications: different size cut-offs, a stricter definition of darkness, "
        "high-confidence detections only, fishing vessels removed, and the Black Sea excluded. Detections from the same satellite image "
        "are not independent, so confidence intervals were obtained by a <b>scene-cluster bootstrap</b> "
        "(2,000 resamples of whole Sentinel-1 scenes). Here 'war zones' means the Gulf and the Black Sea, where the fighting "
        "reached the coast. This is why the baseline relative risk differs slightly from Chapter 7, which also counted the Red Sea zone.")
    d.fig("f9_2_robustness", "Relative risk of AIS darkness under alternative specifications (scene-cluster bootstrap 95% CI)")
    rb = T("t9_2_robustness")
    d.table(rb, "Robustness of the war-zone darkness effect", small=True)
    d.p(f"Across all eight specifications the relative risk lies between <b>{M['rob_min_rr']:.1f} and {M['rob_max_rr']:.1f}</b>, and the lowest "
        f"lower confidence bound is {M['rob_min_lo']:.1f}. No reasonable choice of definition makes the effect go away.")
    d.table(T("t11_3_pass_robustness"), "Pass-level checks: feed outages and satellite pass time", small=True)
    d.table(T("t11_4_did"), "Difference-in-differences: did the Gulf darken faster than 11 control seas?", small=True)
    d.p(f"Two further threats were tested. <b>Feed outage:</b> {M['alldark_n']} satellite passes were 100% dark, which could be an AIS feed failure "
        f"rather than behaviour. Removing them raises the war-zone relative risk to {M['rr_excl_alldark']:.1f}. <b>Pass geometry:</b> the Gulf SDR is "
        f"{M['gulf_sdr_day']:.0f}% by day and {M['gulf_sdr_night']:.0f}% by night, against {M['world_sdr_day']:.0f}% and {M['world_sdr_night']:.0f}% in peaceful seas. "
        f"<b>Change, not just level:</b> treating each satellite image as one observation, the Gulf SDR rose <b>{M['did_excess']:.1f} percentage points a "
        f"day faster</b> than 11 control seas (whose trend was {M['did_control']:+.2f}), permutation p = {M['did_p']:.3f}. The Gulf darkened during the "
        "fortnight, and nowhere else did.")
    d.section("10.5", "Dose-Response Inside the Gulf")
    d.fig("f9_3_dose_response", "AIS-dark share of large ships by distance from the nearest province with active fighting, Gulf war zone")
    d.table(T("t9_3_dose_response"), "Dose-response of darkness to proximity of fighting (Gulf war zone, ships &ge; 100 m)", small=True)
    d.p(f"Within the Gulf itself, where sensor, season and traffic mix are held constant, darkness falls steadily with distance from the fighting: "
        f"{pct(M['dose_0_50'])} within 50 km, {pct(M['dose_100_150'])} at 100-150 km, and 43 per cent at 150-200 km. Each unit increase in log-distance "
        f"multiplies the odds of darkness by {M['dose_or_per_log']:.2f} (p = {M['dose_p']:.0e}). A graded response to the strength of "
        "exposure is one of the classic criteria for inferring cause rather than coincidence.")
    d.section("10.6", "Analysis of Competing Hypotheses")
    d.p("Following intelligence tradecraft (the Analysis of Competing Hypotheses method), each alternative explanation of the Gulf darkness is scored "
        "against every item of evidence as Consistent (C), Inconsistent (I) or Neutral (N). The hypothesis with the <i>fewest "
        "inconsistencies</i> is preferred, rather than the one with the most support.")
    d.table(T("t9_4_ach"), "Analysis of competing hypotheses for AIS darkness in the Gulf (C = consistent, I = inconsistent, N = neutral)", small=True)
    ai = M["ach_inconsistent"]
    d.p(f"Inconsistencies: <b>deliberate switch-off {ai['H-A Deliberate switch-off']}</b>, GNSS spoofing/jamming "
        f"{ai['H-B GNSS spoofing / jamming']}, AIS reception gap {ai['H-C AIS reception gap']}, matching artefact "
        f"{ai['H-D Matching artefact']}. Reception gaps and algorithm artefacts are effectively ruled out, because they cannot "
        "produce size-selective, distance-graded, war-specific darkness. Deliberate switch-off is the best-supported explanation. "
        "GNSS interference is not ruled out and probably contributes, but the absence of any excess in 'noisy' tracks argues against it "
        "being the main mechanism.")
    d.section("10.7", "Key Judgements and Confidence")
    d.p("Judgements are expressed in the standard language of estimative probability, with a separate statement of analytic "
        "confidence that reflects the quality and quantity of the evidence.")
    d.table(pd.DataFrame([
        ("Almost certain", "&gt; 95%"), ("Highly likely", "80-95%"), ("Likely", "55-80%"), ("Roughly even chance", "45-55%"),
        ("Unlikely", "20-45%"), ("Highly unlikely", "5-20%")], columns=["Term", "Probability"]), "Scale of estimative probability used", small=True)
    KJ = pd.DataFrame([
        ("KJ1", "It is <b>almost certain</b> that the war caused the excess AIS darkness of large ships in the Gulf.", "High", "RR 3.9-6.4 under all specifications; dose-response; replicated in the Black Sea"),
        ("KJ2", "It is <b>likely</b> that most of the darkness is deliberate switch-off; GNSS interference <b>probably</b> contributes. A failed match proves identification failure, not intent.", "Moderate", "ACH: 0 inconsistencies for switch-off; ships held at anchor (stasis); intent cannot be observed"),
        ("KJ3", "It is <b>highly likely</b> that the Hormuz littoral stays above its disruption threshold at least intermittently through Q3-2026.", "Moderate", f"{pct(M['fc_prob_above_thr'])} of simulated paths breach; I&W status Red at end of data"),
        ("KJ4", f"A chokepoint disruption <b>likely</b> outlasts India's SPR (about {pct(M['km_p_gt_spr'])}); outlasting total national cover is <b>highly unlikely</b> (about {pct(M['km_p_gt_74d'])}) but not negligible.", "Moderate", "Kaplan-Meier on 32 episodes; wide intervals"),
        ("KJ5", "It is <b>almost certain</b> that stand-off weapons will remain the dominant threat to rear-area logistics and energy nodes in regional wars.", "High", "84% of war-period violence; consistent across 2024 and 2026 wars"),
        ("KJ6", "It is <b>likely</b> that the Strategic Dark Ratio (SDR) leads measurable trade disruption.", "Low", "Plausible and consistent with anchorage clustering; not yet tested against flow data"),
        ("KJ7", "It is <b>highly likely</b> that open conflict and satellite indicators give earlier warning than market prices.", "Moderate", f"Prices react only to events (Granger p &gt; 0.4); June call Red at US${M['brent_at_cut']:.0f}, then +{M['brent_oos_change']:.0f}%; one out-of-sample test"),
    ], columns=["#", "Judgement", "Confidence", "Basis"])
    d.table(KJ, "Key judgements")
    d.section("10.8", "Limitations")
    d.bullets([
        "The SAR data cover only 14 days from a single satellite (Sentinel-1A), so the pre-war level of darkness in the same waters cannot be observed directly. "
        "Peacetime regions and the Black Sea serve as the comparison groups instead.",
        "'Unmatched' is not always deliberate: GNSS spoofing, AIS reception gaps and matching-algorithm limits also produce "
        "darkness. In the Gulf these are themselves effects of the war.",
        "ACLED aggregates are at ADMIN1 resolution, and its at-sea events carry a nominal basin centroid. Distances to conflict are therefore approximate.",
        "The survival analysis rests on 32 episodes, so Cox coefficients have wide intervals. MID-to-flag decoding and registry "
        "classes are approximations, and registry class is not proof of any particular ship's conduct.",
        "Figures quoted from secondary sources (oil import shares, reserve days, diaspora) are indicative and cited, and they were not "
        "derived from the Datathon datasets.",
    ])
    d.p("None of these limitations reverses the direction of the main inferences. The war-zone effect on large-ship darkness (I1) is "
        "large, significant and reproduced in two unrelated wars. Inferences I4 and I5 should be read as well supported but moderate in precision.")

    # ================================================================== 10 IMPACT - GLOBE
    d.chapter("Impact on the Globe")
    d.bullets([
        "<b>Energy security.</b> About a fifth of the world's oil liquids and a large share of its LNG pass through Hormuz [2]. "
        "F3 and F5 show the strait's shoreline became an active front and stayed above its disruption threshold for most of "
        "February to June 2026. The world energy market now has to price chokepoint risk as a recurring condition, not a rare event (I4).",
        "<b>Freight, time and cost.</b> Where a detour exists, conflict produces diversion (I2). Cape routing adds 10-14 days to "
        "Asia-Europe voyages, absorbs fleet capacity and raises freight and insurance costs worldwide [1]. The survival curves (F5) show "
        "these episodes last weeks to months, not days.",
        "<b>Loss of the common maritime picture.</b> In war zones the cooperative identity system on which collision avoidance, search "
        "and rescue, sanctions enforcement, insurance and port-state control depend fails for most large ships (F6, I1). Navigation safety "
        "deteriorates, and the chance of misidentifying and striking a neutral ship rises.",
        "<b>Sanctions and the shadow fleet.</b> Dark ships cluster at the Gulf and Black Sea anchorages, and shadow-fleet registries are "
        "about three times over-represented among visible ships (F8), although the dark fleet itself is mainly mainstream tonnage. The informal, poorly insured fleet grows exactly where oversight is weakest, raising the risk of "
        "environmental disasters and unattributable incidents (I6).",
        "<b>Contagion of stand-off warfare.</b> Cheap drones and missiles have become the main tool of regional war (F2, I3). Any littoral "
        "actor can now hold a chokepoint at risk from the shore, and the model extends beyond the Middle East to other straits.",
        "<b>A model for other chokepoints.</b> The four signatures identified here (concealment, evacuation, attrition/frozen, compliance; I2) offer a way to anticipate "
        "what would happen in a crisis at Malacca, the Taiwan Strait or the Bosphorus, where the same data and methods can be applied.",
    ])

    # ================================================================== 11 IMPACT - INDIA
    d.chapter("Impact on India")
    d.p("The impact reaches India through a chain that runs from the battlefield to the balance of payments and the defence budget. "
        "Every link in the chain below is measured in this study.")
    d.html_fig(IG.impact_cascade(M), "Impact cascade: from conflict at the chokepoint to India's import bill and the Armed Forces (SmartArt)")
    d.html_fig(IG.cog(M), "Centre-of-gravity analysis: India's economic access to the sea, with measured critical vulnerabilities (after Strange, 1996)")
    d.p("CV1 (Hormuz) and CV3 (price and insurance) are familiar. <b>CV2, the integrity of maritime identification, is the vulnerability this "
        "study adds</b>, and no amount of tonnage fixes it: an escort must know which ship to escort, and in the water where it matters most "
        "three-quarters of the big hulls were not saying.")
    d.bullets([
        "<b>Energy import exposure.</b> India imports close to nine-tenths of its crude oil. Open-source estimates put a large share of that "
        "crude (commonly 40-50 per cent), most of its LPG and much of its LNG as coming from the Gulf through Hormuz [2, 19]. "
        f"The heavy-tailed disruption curve (F5, I4) means that about {pct(M['km_p_gt_spr'])} of disruptions would outlast the strategic "
        f"petroleum reserve (~9.5 days) and about {pct(M['km_p_gt_74d'])} would outlast the total national cover of about 74 days [19]. "
        "Hormuz is a no-detour chokepoint (I2), so for this share of India's energy there is no rerouting option, only buffers and "
        "alternative suppliers.",
        "<b>Trade routes to Europe, Africa and the US East Coast.</b> The Red Sea diversion (F4, F7) lengthens India's westbound "
        "container and product-tanker routes and raises their cost, eroding the competitiveness of exports such as refined products, engineering goods, "
        "textiles and pharmaceuticals. The Houthi campaign episodes lasted a median of four weeks and up to 19 weeks.",
        "<b>Connectivity projects.</b> The International North-South Transport Corridor through Chabahar and the India-Middle East-Europe "
        "Economic Corridor (IMEC) both pass through the theatres analysed. The predicted dark-risk at Chabahar "
        "(Table 8.3) and the violence in Sistan-Baluchestan and Hormozgan (Chapter 5) point to delays and higher risk premia for both.",
        "<b>Diaspora and remittances.</b> About nine million Indians live in the GCC, which sends India a large share of its remittances [20]. "
        f"The {M['gcc_multiplier']:.0f}-fold rise in violence inside the GCC (F3) makes large-scale non-combatant evacuation a planning case, "
        "not a contingency.",
        "<b>Maritime domain awareness at home.</b> India's own seas are dominated by thousands of small, non-AIS craft (F9), and even "
        "AIS-visible identities can be cloned or spoofed (F10). The national maritime picture cannot rely on AIS alone (I6).",
        "<b>An opportunity.</b> The inferences also favour India. National SAR assets (EOS-04, NISAR), the Information Fusion Centre - "
        "Indian Ocean Region, and a growing analytics culture give India the means to turn I1 and I5 into a regional early-warning "
        "service for partners in the Indian Ocean, strengthening its role as a net security provider.",
    ])

    d.p("<b>Own-asset exposure.</b> Decoding the flag of every AIS-visible ship shows how many Indian-flagged vessels were inside the "
        "theatres during the first two weeks of the war. These are only the ships still transmitting; any that went dark are not counted.")
    d.table(T("t9_5_indian_flag"), "Indian-flagged ships detected by Sentinel-1, 1-14 March 2026", small=True)
    d.p(f"At least <b>{M['ind_gulf_ships']} distinct Indian-flagged ships</b> ({M['ind_gulf_large']} detections of ships of 100 m or more) were "
        "operating inside the Gulf war zone in two weeks. This is a lower bound, since Indian-owned tonnage under foreign flags is not identified by the flag decode. "
        "It is the minimum population for which escort, evacuation of crews, and war-risk insurance support would have to be planned.")

    # ================================================================== 12 IMPACT - ARMED FORCES
    d.chapter("Impact on the Indian Armed Forces")
    d.p("The findings affect all three Services and the joint structures that link them. The common threads are fuel and "
        "spares security (I4), the stand-off threat to bases and nodes (I3), and operating in an environment where navigation and "
        "identity can no longer be taken for granted (I1, I6).")
    d.html_fig(IG.triservice(M), "Impact on the Indian Armed Forces at a glance (infographic)")
    d.section("13.1", "Joint and Tri-Service Impact")
    d.bullets([
        "<b>POL and war-wastage reserves.</b> Mechanised formations, ships and aircraft all run on imported crude refined in India. "
        "A chokepoint disruption that outlasts national reserves (F5) would lead to rationing, in which defence consumption competes "
        "with the civil economy. The prescriptive model in Section 13.5 turns F5 into a stock-holding decision.",
        "<b>Imported equipment, spares and ammunition.</b> Sea-lifted defence imports and the spares for imported platforms move on the same "
        "routes. Longer, more variable lead-times (F4, F5, F7) mean that re-order points and safety stocks based on peacetime "
        "lead-times will be too low for all three Services.",
        "<b>Non-combatant evacuation.</b> The rise in GCC violence (F3) makes a large-scale evacuation of the Gulf diaspora a joint "
        "operation to plan now: Navy sealift, IAF airlift and Army reception, transit and medical support. Op Ganga (2022), Op Kaveri (2023) and Op Ajay (2023) are the reference cases.",
        "<b>Space-based surveillance.</b> The study shows what SAR can reveal in a war zone (F6, F8). The Defence Space Agency and "
        "the national SAR constellation are the natural owners of a standing dark-ship and chokepoint watch.",
    ])
    d.section("13.2", "Indian Navy")
    d.bullets([
        "<b>Escort and presence operations.</b> The belt of darkness from Qatar to the Gulf of Oman (F6, H4) is the area in which Indian-flag "
        "tankers and gas carriers would be escorted, as in Op Sankalp. Positive identification of contacts in a picture where 60-74 per cent "
        "of large ships are dark is harder, raising the risk of surprise and of mistaken engagement.",
        "<b>Stand-off threat at sea.</b> The anti-shipping campaign (F4) and the dominance of drones and missiles (F2) call for "
        "ship air defence, counter-drone systems and magazine depth sized for long campaigns (F5), not single incidents.",
        "<b>Coastal security.</b> The thousands of non-AIS small craft in India's near seas (F9) are the population in which a "
        "26/11-type threat hides. Coastal radar, SAR cueing and fishing-vessel transponders are needed alongside AIS.",
        "<b>Shadow fleet in the Indian EEZ.</b> Poorly insured, shadow-registered tankers (F8) crossing India's waters raise the risk of oil "
        "spills and incidents that the Navy and Coast Guard would have to respond to.",
    ])
    d.section("13.3", "Indian Air Force")
    d.bullets([
        "<b>Air-base survivability.</b> GCC energy infrastructure far from any front line was struck directly (F3), and stand-off weapons dominate (F2, I3). "
        "Forward and depth air bases, fuel farms and radars need layered air defence, hardened shelters, dispersal and rapid runway repair.",
        "<b>Air routes and airlift.</b> Violence across the GCC and Iran closes or restricts air corridors to West Asia, Africa and Europe. That "
        "lengthens ferry and airlift routes, including those needed for evacuation and for urgent sustainment of imported spares.",
        "<b>Navigation warfare.</b> The spoofing and identity anomalies seen at sea (F10) are the maritime face of the GNSS "
        "interference that also affects aircraft. Avionics and weapons need multi-constellation (NavIC), anti-jam and inertial fallback.",
    ])
    d.section("13.4", "Indian Army")
    d.bullets([
        "<b>Logistics nodes under stand-off threat.</b> Army depots, railheads, POL points and ammunition storage need the same "
        "layered air defence, counter-UAS, dispersal and hardening that the Gulf's terminals lacked (F2, F3, I3).",
        "<b>GNSS-dependent weapons.</b> Army drones, loitering munitions, precision artillery and timing networks need "
        "NavIC/multi-constellation, anti-jam and GNSS-denied fallback capability, and troops should train under jamming and spoofing (F6, F10).",
        "<b>Western front and hybrid spill-over.</b> Violence in Sistan-Baluchestan (among Iran's most violent provinces over the decade), the Makran "
        "littoral and a weakened Iranian periphery all border Pakistan's Balochistan. These affect the western-front threat picture and the security of connectivity projects.",
        "<b>Sustainment of imported fleets.</b> Armoured, artillery and aviation fleets with imported sub-systems face longer spares "
        "lead-times (F5). Predictive maintenance and survival-based spares forecasting of the kind the author developed for armoured vehicles [13] become more valuable.",
    ])
    d.section("13.5", "Prescriptive Model: How Much Stock Is Enough?")
    d.fig("f9_1_stock_cover", "Prescriptive stock-cover curve from observed Gulf and Red Sea disruption durations")
    st = T("t9_1_stock_decision")
    d.table(st, "Decision table: stock held against disruption risk and expected shortfall",
            fmt={c: (lambda v: f"{v:.1f}") for c in st.columns[1:]})
    d.p(f"With no stock, an average Gulf or Red Sea disruption leaves {M['stock_es_0']:.0f} uncovered days. Holding "
        f"<b>30 days</b> of stock cuts the expected shortfall to {M['stock_es_30']:.1f} days, and <b>45 days</b> to {M['stock_es_45']:.1f} days, "
        f"avoiding 74 per cent of the shortfall. The returns flatten at about <b>{M['stock_knee_days']} days</b>: beyond this point each "
        "additional day of stock removes less than a quarter of a day of expected shortfall. The same curve can be applied to "
        "any disruption-sensitive commodity held by any Service (POL, lubricants, aviation fuel, critical imported spares) to set holdings on evidence rather than precedent.")

    d.fig("f12_5_effective_cover", "Effective cover: how long a stock can replace the share of supply lost behind a closed chokepoint")
    d.p(f"The open data change the question from 'how many days of stock?' to 'how many days of stock <i>per share exposed</i>?'. A full closure "
        f"has already lasted {M['closure_days']}+ days, far beyond any stock. But a stock only has to replace the share of supply that is cut off. "
        f"At India's pre-war exposure of about 45%, 74 days of national cover replaces the lost share for about <b>{M['cover_74_at45']} days</b>; after "
        f"rerouting to about 30% exposure it lasts about <b>{M['cover_74_at30']} days</b>, longer than the closure so far. The SPR alone lasts only about "
        f"{M['cover_spr_at30']} days even at 30%. <b>Stocks bridge; diversification carries.</b> The same arithmetic applies to Service holdings of "
        "fuel and critical imported spares: 35-45 days bridges a flare-up, and dual sourcing is what carries a closure.")
    d.section("13.6", "Scenario Matrix for Force Planning")
    d.p("Joining the survival curve (how long disruptions last) to the stock levels (how long the nation and the Services can hold out) "
        "gives a scenario matrix of the kind used in force planning.")
    d.table(T("t9_7_scenarios"), "Hormuz / Red Sea disruption scenarios: likelihood and uncovered days", small=True)
    d.p(f"<b>S2 (six weeks) is the planning case.</b> It is roughly a one-in-five event on the historical record "
        f"({pct(M['sc_p6'])}). It is fully covered at national level but leaves a 30-day Service holding 12 days short. A 45-day holding covers it completely. "
        f"S3 (twelve weeks, about {pct(M['sc_p12'])}) exceeds every buffer and is the case for which rationing priorities, alternative supply "
        "and the national reserve release order must be prepared in advance.")
    d.p(f"<b>Two clocks, not one.</b> The likelihoods above come from conflict flare-ups (Chapter 6). The shipping record tells a harder story "
        f"(Section 9.12): {pct(M['ship_p_gt_74'])} of chokepoint shipping disruptions outlasted the 74-day national cover, and the Hormuz closure "
        f"had run {M['closure_days']} days by the end of the record. So S2 is the planning case for <i>stock holdings</i>, which must bridge the "
        "first six weeks, while S3-S4 is the planning case for <i>supply</i>, which only diversification (effective cover, Figure 13.3) can carry.")

    # ================================================================== 13 WAY FORWARD
    d.chapter("Way Forward")
    d.p("The way forward has three parts: recommendations traced to the findings and inferences, a phased roadmap to implement "
        "them, and the research that would strengthen the evidence.")
    d.section("14.1", "Recommendations")
    R = pd.DataFrame([
        ("National", "R1", "Treat stocks as a bridge and diversification as the cure: hold 35-45 days to ride out flare-ups, and cut the share of crude exposed to any one chokepoint, because effective cover = stock days / share exposed (74 days lasts ~8 months at 30% exposure but only ~5 months at 45%).", "F5, F16, I4"),
        ("National", "R2", "Diversify energy sources and routes: more non-Gulf crude and LNG, access to Hormuz-bypass export points (Yanbu, Fujairah), and long-term charters that include war-risk clauses.", "F3, F7, I2"),
        ("National", "R3", "Build a national Chokepoint Early-Warning System that tracks the CCII, the stand-off strike share and the Strategic Dark Ratio (SDR) weekly, with the thresholds from this study as triggers.", "F1, F2, F6, I1, I5"),
        ("Maritime / MDA", "R4", "Fuse SAR (NISAR, EOS-04, commercial SAR) with AIS at IFC-IOR and flag every dark large ship automatically, prioritising the hot-spot belt and the predicted dark-risk surface.", "F6, F8, I1"),
        ("Maritime / MDA", "R5", "Treat AIS identity as untrusted: build automated checks for impossible re-sightings, placeholder and malformed MMSIs and shadow-fleet registries, and share them with ports and insurers.", "F10, I6"),
        ("Maritime / MDA", "R6", "Extend coverage of small craft in India's seas (fishing-vessel transponders, coastal radar, SAR) so that the non-AIS population is known.", "F9, I6"),
        ("Joint (HQ IDS)", "R7", "Re-baseline POL, lubricant, aviation-fuel and critical-spares War Wastage Reserves for all three Services using the expected-shortfall method (Eq. 3.6), and re-order points using lead-time distributions measured during crises.", "F4, F5, I4"),
        ("Joint (HQ IDS)", "R8", "Set up a tri-service Data Analytics Cell under HQ IDS, with Service nodes (DG Log, DGMO, Naval Operations, Air Operations), that runs this pipeline and its Power BI dashboard as a standing supply-chain and conflict early-warning product.", "All"),
        ("Joint (HQ IDS)", "R9", "Pre-plan non-combatant evacuation from the GCC as a live case and rehearse Navy sealift, IAF airlift and Army reception, transit and medical components together.", "F3"),
        ("Indian Navy", "R10", "Use SAR dark-ship cueing and the predicted dark-risk surface for escort and presence operations in the Gulf and Arabian Sea; plan ship air defence and counter-drone magazines for long campaigns.", "F2, F4, F6"),
        ("Indian Air Force", "R11", "Harden and disperse air bases and fuel farms against stand-off strikes, and make multi-GNSS/NavIC, anti-jam and inertial fallback standard for avionics and weapons.", "F2, F3, F10, I3"),
        ("Indian Army", "R12", "Give priority to layered air defence, counter-UAS, dispersal and hardening of depots, POL points and railheads, and make GNSS resilience mandatory for drones, loitering munitions and precision fires.", "F2, F3, F10, I3"),
        ("All Services", "R13", "Weight indigenisation (Aatmanirbharta) priority lists by route exposure, so that items that move through Hormuz or the Red Sea and have long lead-times are indigenised or dual-sourced first.", "F4, F5, F7"),
        ("All Services", "R14", "Standing instruction: no AIS-derived traffic count for a contested corridor may be used in an assessment without an SDR check or a non-cooperative sensor cross-check.", "F13, I6"),
        ("Joint (HQ IDS)", "R15", "Institutionalise post-crisis maritime assessment: archive corridor SAR imagery and write up what shipping actually did after every chokepoint disruption.", "F13, F14"),
    ], columns=["Level", "#", "Recommendation", "Based on"])
    d.table(R, "Recommendations traced to findings (F) and inferences (I)", breakable=True)
    d.p("<b>Staffing.</b> Each recommendation below has a lead, a timeline and a measure of effectiveness, so that it can be actioned and "
        "judged rather than merely noted.")
    STF = pd.DataFrame([
        ("R3, R8, R14", "HQ IDS (DIA) with IFC-IOR", "4 months (Phase 1)", "Weekly corridor-integrity brief read and acted on by a principal; at least one AMBER not already obvious from other reporting"),
        ("R4, R5, R10", "Indian Navy (IFC-IOR), DSA", "6-18 months", "Share of dark big hulls in the Gulf belt cued within 24 h of a Sentinel-1 or national SAR pass"),
        ("R1, R2", "MoPNG with MEA, MoD", "12 months", "National cover set on the survival curve; share of Hormuz-dependent crude with pre-cleared alternatives"),
        ("R7", "HQ IDS (DCIDS Log) with Service log staffs", "6 months", "WWR norms re-computed with Eq. 3.6; days of cover held against the 35-45 day band"),
        ("R11, R12", "IAF / Army AD, DG EME", "Rolling, 3 years", "Share of critical nodes with layered AD and counter-UAS; GNSS-denied drills completed"),
        ("R9", "HQ IDS with MEA", "3 months, then annual", "NEO plan exercised tri-service; time to first lift from alert"),
        ("R15", "HQ IDS, CDM", "After each crisis", "Post-crisis maritime report issued within 90 days"),
    ], columns=["Recommendations", "Lead", "Timeline", "Measure of effectiveness"])
    d.table(STF, "Staffing of the recommendations", small=True)
    d.section("14.2", "DARKWATCH: the Indicators and Warnings (I&W) Matrix")
    d.p("The findings are turned into a watch-list of six indicators, named <b>DARKWATCH</b>. Each is measurable every week from open data and has "
        "Amber and Red thresholds and a pre-agreed action. The status shown is at the end of the data (week of 27 June 2026). "
        "This matrix is the core of the recommended weekly early-warning brief (R3, R8) and of page 2 of the Power BI dashboard.")
    iwt = T("t9_6_iw_matrix")
    d.html_fig(IG.iw_dashboard(M, iwt), "I&amp;W dashboard at 27 June 2026, with the out-of-sample oil-price test")
    d.table(iwt, "Indicators and warnings matrix - status at 27 June 2026", small=True,
            fmt={"Status": lambda v: f'<span class="rag {v.lower()}">{v}</span>'})
    d.p(f"<b>Status: {M['iw_red']} Red, {M['iw_amber']} Amber, 0 Green.</b> Four months after the war began and ten weeks after the "
        "de-escalation break, the Hormuz littoral is still at three to four times its disruption threshold and the Red Sea at-sea index remains above its "
        f"threshold. Stand-off strikes are {pct(M['iw_standoff'])} of all violence, against {pct(M['iw_standoff_base'])} in the pre-war year. The situation is "
        "not one of recovery. It is a sustained, lower-intensity disruption, and the buffers recommended in Chapter 13 should be held, not released.")
    d.section("14.3", "Phased Roadmap")
    d.html_fig(IG.roadmap(), "Way-forward roadmap (SmartArt)")
    W = pd.DataFrame([
        ("Phase 1 (0-4 months): proof of concept at no new cost", "Institutionalise the pipeline using existing establishment, free Copernicus Sentinel-1 imagery and this code. Host the Power BI dashboard (Appendix B) at HQ IDS and Service HQs; run the weekly CCII and "
         "stand-off-share refresh from ACLED; set alert thresholds; start the tri-service WWR review using Eq. 3.6.",
         "Weekly DARKWATCH brief; revised stock norms for trial. <b>Stop test:</b> has a principal acted on a DARKWATCH AMBER? If not, stop."),
        ("Phase 2 (4-18 months)", "Fuse sensors and automate. Ingest national SAR (NISAR, EOS-04) and commercial SAR with AIS; run automated "
         "dark-ship and identity-anomaly detection; retrain the dark-spot model monthly; add freight-rate, insurance and port-call data "
         "to measure physical impact directly.", "Near-real-time dark-ship alerts; validated dark-risk maps. <b>Stop test:</b> did the four signatures hold on a second crisis?"),
        ("Phase 3 (18-36 months)", "Move to prescriptive, joint decision support. Integrate with the tri-service logistics and inventory systems; "
         "simulate stock, route and evacuation decisions under scenarios; extend the same methods to the South China Sea "
         "and Malacca theatres; train staff in data-driven logistics through CDM and Service analytics courses.",
         "Joint supply-chain resilience system; trained analytics cadre. <b>Stop test:</b> does the capability survive the posting-out of its first officers?"),
    ], columns=["Phase", "Actions", "Deliverable and stop/go test"])
    d.table(W, "Phased roadmap")
    d.section("14.4", "Future Research")
    d.p("Several extensions would strengthen the results: (a) extend the SAR window to a pre-war baseline for the same "
        "waters, which would give a true difference-in-differences estimate of war-induced darkness; (b) add ship-level AIS gap "
        "events and port calls to measure turnaround and diversion directly; (c) model GNSS-interference zones explicitly to separate "
        "spoofing from deliberate switch-off; (d) move from ADMIN1 centroids to event-level ACLED coordinates.")

    # ================================================================== 14 CONCLUSION
    d.chapter("Conclusion")
    d.p("This study set out to measure how global, and in particular Middle-East, conflicts affect maritime supply chains, to locate and "
        "predict AIS dark zones, and to turn the results into guidance for India and its Armed Forces. All six hypotheses are supported by the data.")
    d.section("15.1", "Conflict Analytics")
    d.bullets([
        f"Middle-East political violence moved through distinct regimes, and change-point detection dated the shifts to 7 October 2023 and 28 February 2026 without being given them. The war regime ran at {M['pv_war_ratio']:.1f} times the preceding year.",
        f"The 2026 war was fought mainly with stand-off weapons (84 per cent of violence), reached the GCC energy coast ({M['gcc_multiplier']:.0f}-fold rise) and put the Hormuz littoral at {M['hormuz_war_mult']:.0f} times its baseline.",
        "In the Red Sea the threat moved offshore. Chokepoint risk must be measured at sea, not only on land.",
    ], "alpha")
    d.section("15.2", "Disruption Survival")
    d.bullets([
        f"Disruption episodes are heavy-tailed (median {M['ep_median_wk']:.1f} weeks, longest {M['ep_max_wk']} weeks). {pct(M['km_p_gt_spr'])} outlast India's strategic reserve and {pct(M['km_p_gt_74d'])} outlast total national cover.",
        f"Holding about 35-45 days of stock covers most of the expected shortfall. Beyond about {M['stock_knee_days']} days each extra day of stock adds little protection.",
    ], "alpha")
    d.section("15.3", "AIS Dark Zones")
    d.bullets([
        f"Large ships were AIS-dark in {pct(M['hormuz_large_dark'])} of cases in the Strait of Hormuz and {pct(M['black_large_dark'])} in the Black Sea, against about 10 per cent in peacetime waters (relative risk {M['large_rr']:.1f}). The identification crisis named in the problem statement is real and measurable.",
        "The same war produced four behaviours at sea: concealment in the Gulf, evacuation from the Red Sea, a frozen Black Sea and compliance in the East Med. Dark tankers were held at the Gulf anchorages; the dark fleet was mainly mainstream tonnage, not a rogue fleet.",
        f"Proximity to conflict predicts darkness in sea regions the model never saw (ROC-AUC {M['auc_gbt']:.2f}), which makes it possible to forecast where the maritime picture will fail.",
    ], "alpha")
    d.section("15.4", "Implications")
    d.p("For the globe, chokepoint risk has become a recurring cost of trade and a hazard to navigation. For India, the exposure is "
        "concentrated in Gulf energy, westbound trade, connectivity projects and the Gulf diaspora. For the Indian Armed Forces, the "
        "same evidence calls for fuel and spares reserves sized on the survival curve, bases and nodes hardened against stand-off "
        "attack, navigation that does not depend on GNSS alone, and a joint data cell that watches the chokepoints every week.")
    d.p(f"The central inference was stress-tested the way an intelligence judgement should be. It survives eight alternative specifications "
        f"(relative risk {M['rob_min_rr']:.1f}-{M['rob_max_rr']:.1f}) and shows a clear dose-response with distance from the fighting. "
        "Of the competing explanations, only deliberate switch-off is consistent with all the evidence. At the end of the data, the I&W matrix "
        f"stands at {M['iw_red']} Red and {M['iw_amber']} Amber: the disruption has not ended.")
    d.html_fig(IG.takeaways(M), "Five takeaways (infographic)")
    d.p("<b>Closing statement.</b> The first casualty of war at a chokepoint is <i>visibility</i>. Physical disruption follows it, lasts "
        "longer than intuition suggests, and reaches India's energy, trade, diaspora and military sustainment. The same data and methods "
        "that measured this can warn of it. By turning the pipeline, index, dark-spot model and stock-cover curve built here into standing tools, "
        "India and the Indian Armed Forces can base these decisions on data rather than on precedent, which is the aim of the Datathon.")

    # ================================================================== REFERENCES
    d.chapter("References")
    refs = [
        "UNCTAD (2024). <i>Review of Maritime Transport 2024: Navigating maritime chokepoints</i>. United Nations Conference on Trade and Development, Geneva.",
        "U.S. Energy Information Administration (2024). <i>World Oil Transit Chokepoints</i> and <i>Amid regional conflict, the Strait of Hormuz remains critical oil chokepoint</i>. EIA, Washington DC.",
        "College of Defence Management (2026). <i>Datathon-2026: General Instructions</i> and theme datasets 'Global Conflicts - Impact on Supply Chains'. CDM, Secunderabad, under HQ IDS.",
        "Raleigh, C., Linke, A., Hegre, H. and Karlsen, J. (2010). Introducing ACLED: An Armed Conflict Location and Event Dataset. <i>Journal of Peace Research</i>, 47(5), 651-660. Data: ACLED Middle East aggregated data to week of 27 June 2026, www.acleddata.com.",
        "Paolo, F.S., Kroodsma, D., Raynor, J. et al. (2024). Satellite mapping reveals extensive industrial activity at sea. <i>Nature</i>, 625, 85-91. Data: Global Fishing Watch SAR vessel detections.",
        "Killick, R., Fearnhead, P. and Eckley, I.A. (2012). Optimal detection of changepoints with a linear computational cost. <i>Journal of the American Statistical Association</i>, 107(500), 1590-1598.",
        "Truong, C., Oudre, L. and Vayatis, N. (2020). Selective review of offline change point detection methods. <i>Signal Processing</i>, 167, 107299.",
        "Getis, A. and Ord, J.K. (1992). The analysis of spatial association by use of distance statistics. <i>Geographical Analysis</i>, 24(3), 189-206.",
        "Ord, J.K. and Getis, A. (1995). Local spatial autocorrelation statistics: distributional issues and an application. <i>Geographical Analysis</i>, 27(4), 286-306.",
        "Ester, M., Kriegel, H.-P., Sander, J. and Xu, X. (1996). A density-based algorithm for discovering clusters in large spatial databases with noise. <i>Proc. KDD-96</i>, 226-231.",
        "Kaplan, E.L. and Meier, P. (1958). Nonparametric estimation from incomplete observations. <i>Journal of the American Statistical Association</i>, 53(282), 457-481.",
        "Cox, D.R. (1972). Regression models and life-tables. <i>Journal of the Royal Statistical Society, Series B</i>, 34(2), 187-220.",
        "Jayadev, A. (2021). <i>Predictive Maintenance in Armed Forces: A Machine Learning Based Decision Support System</i>. M.Tech Project Report, Department of Mechanical Engineering, IIT Kharagpur.",
        "Roberts, D.R., Bahn, V., Ciuti, S. et al. (2017). Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure. <i>Ecography</i>, 40(8), 913-929.",
        "Friedman, J.H. (2001). Greedy function approximation: a gradient boosting machine. <i>Annals of Statistics</i>, 29(5), 1189-1232.",
        "Hyndman, R.J. and Athanasopoulos, G. (2021). <i>Forecasting: Principles and Practice</i>, 3rd ed. OTexts, Melbourne.",
        "International Maritime Organization. <i>SOLAS Chapter V, Regulation 19</i> - Carriage requirements for shipborne navigational systems and equipment (AIS).",
        "Wilson, E.B. (1927). Probable inference, the law of succession, and statistical inference. <i>Journal of the American Statistical Association</i>, 22(158), 209-212.",
        "Ministry of Petroleum and Natural Gas / Petroleum Planning and Analysis Cell (PPAC), Government of India. Import dependence statistics; Indian Strategic Petroleum Reserves Ltd (ISPRL) capacity (5.33 MMT) and statements on national stock cover.",
        "Ministry of External Affairs, Government of India. Population of Overseas Indians; Reserve Bank of India, Survey on Cross-Border Inward Remittances.",
        "U.S. Energy Information Administration, Europe Brent and Cushing WTI spot prices (daily), via the open 'datasets/oil-prices' repository (github.com/datasets/oil-prices), accessed 23 Sep 2026.",
        "Board of Governors of the Federal Reserve System, H.10 Foreign Exchange Rates (INR per US$), via 'datasets/exchange-rates' (github.com/datasets/exchange-rates), accessed 23 Sep 2026.",
        "Energy Institute (2025). <i>Statistical Review of World Energy</i>; processed by Our World in Data, energy dataset (github.com/owid/energy-data).",
        "Natural Earth (public domain). 1:10m Cultural Vectors - Ports. naturalearthdata.com. Icons in the infographics: Font Awesome Free 6 (CC BY 4.0).",
        "Strange, J. (1996). <i>Centers of Gravity &amp; Critical Vulnerabilities</i>. Perspectives on Warfighting No. 4, Marine Corps University, Quantico.",
        "International Monetary Fund, <i>PortWatch</i>: Daily Chokepoint Transit Calls and Trade Volume Estimates (portwatch.imf.org), 2019 - 16 Aug 2026; raw extract via an MIT-licensed public mirror (github.com/ebiisharifi/hormuz-chokepoint-analytics).",
        "Press Information Bureau (1 Feb 2026). Ministry of Defence allocated an all-time high of Rs 7.85 lakh crore in Union Budget 2026-27.",
        "All India Radio News (11 Mar 2026). India secures 70% of crude oil imports outside Strait of Hormuz: Petroleum Ministry.",
        "Operation Urja Suraksha (Indian Navy escort of Indian-flagged energy carriers, from 23 Mar 2026). Wikipedia and contemporary news reports.",
        "The National (17 Jul 2026). War-risk shipping premium surges again as tensions escalate at Strait of Hormuz; Al Jazeera (23 Jul 2026). How shipping insurance rates are rising as Hormuz, Bab al-Mandeb shut down.",
        "CNBC (18 Mar 2026). Traffic is trickling through Strait of Hormuz: who's moving and who's stranded; straits.live, Strait of Hormuz closure tracker (accessed 23 Sep 2026).",
    ]
    d.add('<ol style="font-size:10.5pt;line-height:1.4;padding-left:20pt">' + "".join(f"<li style='margin-bottom:4pt;text-align:left'>{r}</li>" for r in refs) + "</ol>")

    # ================================================================== APPENDICES
    d.chapter("Appendix A - Toolchain and Reproducibility", letter="A")
    d.p("The analysis is fully scripted. The repository folder <i>datathon2026/</i> contains the pipeline below. Running "
        "<i>python analysis/run_all.py</i> rebuilds every artefact from the two raw files in about one minute on a laptop.")
    d.add('<div class="code">datathon2026/\n'
          '  analysis/common.py              shared styling, regions, chokepoints, MMSI-MID registry, helpers\n'
          '  analysis/01_preprocess.py       cleaning, validation, feature engineering, conflict spatial join\n'
          '  analysis/02_conflict.py         Chapter 5: trends, event mix, heat map, PELT regimes, GCC spill-over, maps\n'
          '  analysis/03_chokepoint_index.py Chapter 6: CCII, thresholds, ARIMA back-test and forecast, Kaplan-Meier, Cox\n'
          '  analysis/04_sar.py              Chapter 7: dark shares, chi-square, Gi* hot spots, DBSCAN, flags, identity\n'
          '  analysis/05_model.py            Chapter 8: logit, gradient-boosted trees, spatial CV, risk surface\n'
          '  analysis/06_decision.py         Section 13.5: expected-shortfall stock-cover model\n'
          '  analysis/07_powerbi_export.py   star-schema tables for the Power BI dashboard\n'
          '  figures/  tables/  powerbi/  data/metrics.json  report/build_report.py</div>')
    d.table(pd.DataFrame([
        ("Language / runtime", "Python 3.11"),
        ("Data manipulation", "pandas 2.x, NumPy, PyArrow (Parquet)"),
        ("Statistics", "SciPy (Mann-Whitney, chi-square, Spearman), statsmodels (Logit, ARIMA/SARIMAX, ETS, Kaplan-Meier, Cox PHReg, Wilson CI)"),
        ("Machine learning", "scikit-learn (HistGradientBoosting with monotonic constraints, GroupKFold spatial CV, DBSCAN, BallTree, permutation importance)"),
        ("Time series", "ruptures (PELT change-points)"),
        ("Visualisation / GIS", "Matplotlib, Basemap (coastlines), custom Getis-Ord Gi*"),
        ("Dashboard", "Microsoft Power BI Desktop (.pbix) on the exported star schema"),
        ("Report", "HTML/CSS rendered to PDF with headless Chromium; all numbers injected from metrics.json"),
    ], columns=["Layer", "Tools"]), "Software stack")
    d.chapter("Appendix B - Power BI Dashboard Data Model", letter="B")
    d.p("The Datathon requires a Power BI (.pbix) file alongside this report. The pipeline exports a star schema "
        "(<i>powerbi/</i>) that loads directly into Power BI Desktop. The model, relationships and core DAX measures are given below. "
        "The step-by-step build of the four dashboard pages is in <i>powerbi/POWERBI_BUILD_GUIDE.md</i>.")
    d.table(pd.DataFrame([
        ("FactConflictWeekly", "149,814", "WEEK, ADMIN1_ID, EVENT_TYPE, SUB_EVENT_TYPE, EVENTS, FATALITIES, flags", "ADMIN1_ID -> DimAdmin1; WEEK -> DimDate[DATE]"),
        ("DimAdmin1", "243", "ADMIN1_ID, COUNTRY, ADMIN1, LAT, LON, GCC, MARITIME, KM_TO_HORMUZ ...", "-"),
        ("FactVesselDetections", "106,533", "DETECTION_ID, DATE, lat, lon, REGION, ZONE, length_m, AIS_DARK, LARGE_100M, flag, flag_class ...", "DATE -> DimDate[DATE]"),
        ("DimDate", "4,383", "DATE, YEAR, QUARTER, MONTH, WEEK_START", "-"),
        ("t6_ccii_weekly, t6_2_episodes, t7_4_dark_clusters, t8_3_poi_risk, t9_1_stock_decision", "-", "analysis outputs", "stand-alone"),
    ], columns=["Table", "Rows", "Key columns", "Relationship"]), "Power BI star schema", small=True)
    d.add('<div class="code">Events            = SUM(FactConflictWeekly[EVENTS])\n'
          'Fatalities        = SUM(FactConflictWeekly[FATALITIES])\n'
          'Stand-off share   = DIVIDE(CALCULATE([Events], FactConflictWeekly[DRONE_MISSILE] = TRUE()),\n'
          '                           CALCULATE([Events], FactConflictWeekly[POLITICAL_VIOLENCE] = TRUE()))\n'
          'Detections        = COUNTROWS(FactVesselDetections)\n'
          'Dark share        = DIVIDE(CALCULATE([Detections], FactVesselDetections[AIS_DARK] = TRUE()), [Detections])\n'
          'Dark share large  = CALCULATE([Dark share], FactVesselDetections[LARGE_100M] = TRUE())\n'
          'Dark RR vs world  = DIVIDE([Dark share large],\n'
          '                           CALCULATE([Dark share large], FactVesselDetections[ZONE] = "Rest of world"))</div>')
    d.p("<b>Dashboard pages.</b> (1) Conflict Pulse: weekly events and fatalities, event-type mix, map of ADMIN1 bubbles, GCC slicer. "
        "(2) Chokepoint Watch: CCII lines by theatre with threshold lines, episode table, forecast. (3) Dark Ships: map of detections "
        "coloured by AIS_DARK, dark share by region and size, cluster table, flag class. (4) Decision: stock-cover decision table, "
        "points-of-interest risk, and a what-if parameter for days of stock.")
    return d


# Front matter with real page numbers: title page, declaration, acknowledgement, abstract, executive summary,
# study at a glance, glossary, abbreviations, list of figures, list of tables, table of contents.
def front_html(body, pages, fp=None):
    fp = fp or {}
    toc = []
    for mid, lvl, lab, title in body.sec:
        if lvl > 2 and not title.startswith(("Proportions", "Change-point")):
            pass
        toc.append(f'<tr class="l{lvl}"><td class="t">{lab}&nbsp;&nbsp;{title}</td><td class="pg">{pages.get(mid, "")}</td></tr>')
    lof = "".join(f'<tr><td style="width:62pt">Figure {lab}</td><td class="t">{cap}</td><td class="pg">{pages.get(mid, "")}</td></tr>'
                  for mid, lab, cap in body.figs)
    lot = "".join(f'<tr><td style="width:56pt">Table {lab}</td><td class="t">{cap}</td><td class="pg">{pages.get(mid, "")}</td></tr>'
                  for mid, lab, cap in body.tabs)
    abbr = [("ACLED", "Armed Conflict Location & Event Data"), ("AIS", "Automatic Identification System"),
            ("AUC", "Area Under the (ROC) Curve"), ("CCII", "Chokepoint Conflict Intensity Index"),
            ("CI", "Confidence Interval"), ("DBSCAN", "Density-Based Spatial Clustering of Applications with Noise"),
            ("FoC", "Flag of Convenience"), ("GBT", "Gradient-Boosted Trees"), ("GCC", "Gulf Cooperation Council"),
            ("GNSS", "Global Navigation Satellite System"), ("HR", "Hazard Ratio"), ("IFC-IOR", "Information Fusion Centre - Indian Ocean Region"),
            ("IMEC", "India-Middle East-Europe Economic Corridor"), ("INSTC", "International North-South Transport Corridor"),
            ("KM", "Kaplan-Meier"), ("MDA", "Maritime Domain Awareness"), ("MID", "Maritime Identification Digits"),
            ("MMSI", "Maritime Mobile Service Identity"), ("OR", "Odds Ratio"), ("PELT", "Pruned Exact Linear Time"),
            ("POL", "Petroleum, Oil and Lubricants"), ("RR", "Relative Risk"), ("SAR", "Synthetic Aperture Radar"),
            ("SPR", "Strategic Petroleum Reserve"), ("VLCC", "Very Large Crude Carrier"), ("WWR", "War Wastage Reserve")]
    ab = "".join(f"<tr><td style='width:70pt'><b>{a}</b></td><td>{b}</td></tr>" for a, b in abbr)
    abstract = (
        "<p>The Datathon-2026 theme <i>Global Conflicts - Impact on Supply Chains</i> asks how conflicts affect world shipping, "
        "and specifically asks participants to identify AIS dead zones and relate them to the identification crisis created by local "
        "conflicts. This study combines eleven and a half years of weekly Middle-East conflict data (ACLED; "
        f"{n(M['acled_events'])} events) with {n(M['sar_rows'])} Sentinel-1 radar vessel detections matched to AIS during the first "
        "two weeks of the 2026 regional war (1-14 March 2026).</p>"
        "<p>Change-point detection dates the regime shifts in regional violence to 7 October 2023 and 28 February 2026 "
        f"without being given either date. The war regime ran at {M['pv_war_ratio']:.1f} times the previous year's rate and was dominated (84 per cent) by "
        f"stand-off strikes, which reached the GCC energy coast ({M['gcc_multiplier']:.0f}-fold rise). A new Chokepoint Conflict Intensity "
        "Index shows that the Red Sea threat moved offshore and that the Hormuz littoral reached "
        f"{M['hormuz_war_mult']:.0f} times its baseline. Survival analysis of {M['ep_n']} disruption episodes shows a heavy tail: "
        f"{pct(M['km_p_gt_spr'])} outlast India's strategic petroleum reserve.</p>"
        f"<p>Large ships were AIS-dark in {pct(M['hormuz_large_dark'])} of cases in the Strait of Hormuz and {pct(M['black_large_dark'])} in "
        f"the Black Sea, against about 10 per cent in peacetime waters (relative risk {M['large_rr']:.1f}, odds ratio {M['large_or']:.1f}). "
        "Getis-Ord hot spots and DBSCAN clusters locate fleets of dark tankers waiting at the Dubai and Fujairah anchorages. A "
        f"gradient-boosted model validated on unseen sea regions (ROC-AUC {M['auc_gbt']:.2f}) predicts AIS dark spots from "
        "conflict geography. Open-source oil-price, exchange-rate and energy data show the Hormuz war raised Brent by up to "
        f"{M['ev_war_peak']:.0f}% and added about US${M['extra_bill_usd_bn']:.0f} billion to India's oil bill. The study's June 2026 early-warning "
        f"call (Red, with Brent back at US${M['brent_at_cut']:.0f}) was followed by an {M['brent_oos_change']:.0f}% rise in oil prices.</p>"
        "<p>The main inference is that the first measurable effect of war at a chokepoint is the <i>blinding</i> of the supply chain, "
        "followed by physical disruption that lasts longer than national buffers. The report then assesses the impact on the globe, on India "
        "and on the Indian Armed Forces (Navy, Air Force, Army and joint), gives a prescriptive stock-cover model (returns flatten at about "
        f"{M['stock_knee_days']} days of cover), and sets out a way forward of fifteen staffed recommendations, a phased roadmap and a Power BI "
        "decision dashboard, before concluding.</p>"
        "<p><b>Keywords:</b> supply chain, chokepoints, AIS dark vessels, SAR, ACLED, change-point detection, Getis-Ord Gi*, DBSCAN, "
        "survival analysis, spatial cross-validation, Indian Armed Forces logistics.</p>")
    return f"""<div class="titlepage">
<div class="t3">COLLEGE OF DEFENCE MANAGEMENT &middot; DATATHON - 2026</div>
<div class="t3" style="margin-bottom:34pt">Theme: Global Conflicts &ndash; Impact on Supply Chains</div>
<div class="t1">{TITLE}</div><div class="t2">{SUBTITLE}</div>
<div class="t3">Submitted by</div><div class="t3"><b>{RANK} {AUTHOR.upper()}</b></div><div class="t3">{SERVICE_NO} &middot; {UNIT}</div>
<div class="t3" style="margin-top:34pt">Submitted to the Faculty of Decision Sciences, College of Defence Management, Secunderabad</div>
<div class="t3">under the aegis of HQ Integrated Defence Staff</div><div class="t3" style="margin-top:26pt">September 2026</div>
<div class="t3" style="margin-top:40pt;font-size:10pt;color:#444">Accompanying files: Power BI dashboard (.pbix), star-schema data tables, analysis source code</div></div>
<div class="front pb"><h1>DECLARATION</h1>
<p>I hereby certify that:</p><ul>
<li>The work in this report is original and has been done by me for Datathon-2026 of the College of Defence Management.</li>
<li>The analysis uses the unclassified datasets provided on the CDM website and open-source literature. No classified information has been used.</li>
<li>Due credit has been given to all data, inferences and references from external sources, and they are cited appropriately.</li>
<li>All figures, tables and statistics can be reproduced from the submitted code and data.</li></ul>
<div class="sig"><div>Place: ____________<br>Date: &nbsp;&nbsp;&nbsp;September 2026</div><div style="text-align:right">({RANK} {AUTHOR})<br>{SERVICE_NO}</div></div></div>
<div class="front pb"><h1>ACKNOWLEDGEMENT</h1>
<p>I thank the College of Defence Management and HQ Integrated Defence Staff for conducting Datathon-2026 and for placing
contemporary, unclassified datasets in the hands of serving officers. I am grateful to my Commanding Officer and superiors for
their encouragement, and to the open-data communities (ACLED, Global Fishing Watch, Copernicus Sentinel-1) whose work made this study possible.
The analytical grounding I received during my M.Tech at IIT Kharagpur, where I applied survival analysis to predictive maintenance
of armoured vehicles, shaped much of the method used here.</p></div>
<div class="front pb"><h1>ABSTRACT</h1>{abstract}</div>
<div class="front pb es"><h1>EXECUTIVE SUMMARY</h1>{ST.exec_summary_story(M)}</div>
<div class="front pb"><h1>THE STUDY AT A GLANCE</h1>{IG.at_a_glance(M)}</div>
<div class="front pb"><h1>DATA ANALYTICS IN PLAIN WORDS</h1>{ST.glossary_html()}</div>
<div class="front pb"><h1>LIST OF ABBREVIATIONS</h1><table class="toc">{ab}</table></div>
<div class="front pb"><h1>LIST OF FIGURES</h1><table class="toc">{lof}</table></div>
<div class="front pb"><h1>LIST OF TABLES</h1><table class="toc">{lot}</table></div>
<div class="front pb"><h1>TABLE OF CONTENTS</h1><table class="toc">
<tr class="l1"><td class="t">Abstract</td><td class="pg">{fp.get("ABSTRACT", "")}</td></tr>
<tr class="l1"><td class="t">Executive Summary</td><td class="pg">{fp.get("EXECUTIVE SUMMARY", "")}</td></tr>
<tr class="l1"><td class="t">The Study at a Glance</td><td class="pg">{fp.get("THE STUDY AT A GLANCE", "")}</td></tr>
<tr class="l1"><td class="t">Data Analytics in Plain Words</td><td class="pg">{fp.get("DATA ANALYTICS IN PLAIN WORDS", "")}</td></tr>
<tr class="l1"><td class="t">List of Abbreviations</td><td class="pg">{fp.get("LIST OF ABBREVIATIONS", "")}</td></tr>
<tr class="l1"><td class="t">List of Figures</td><td class="pg">{fp.get("LIST OF FIGURES", "")}</td></tr>
<tr class="l1"><td class="t">List of Tables</td><td class="pg">{fp.get("LIST OF TABLES", "")}</td></tr>
{''.join(toc)}</table></div>"""


# Executive summary in decision-brief form (bottom line up front, key judgements, actions).
def exec_summary():
    a_ = M["ach_inconsistent"]
    return f"""
<div class="bluf"><b>BOTTOM LINE UP FRONT.</b> War at a chokepoint first <b>blinds</b> the supply chain and then <b>outlasts</b> the buffers.
In the first fortnight of the 2026 war, {pct(M['hormuz_large_dark'])} of large ships in the Strait of Hormuz were AIS-dark, against about 10% in peacetime waters.
Chokepoint disruptions are heavy-tailed: {pct(M['km_p_gt_spr'])} outlast India's strategic petroleum reserve. At the end of the data (27 Jun 2026)
the early-warning matrix stands at <b>{M['iw_red']} Red / {M['iw_amber']} Amber</b>. Hold buffers at <b>35-45 days</b>, harden rear areas against stand-off strikes,
and stand up a joint data cell to watch the chokepoints weekly.</div>
<h2>Key judgements</h2><ul>
<li><b>Almost certain (High confidence):</b> the war caused the excess darkness of large ships. The effect holds under 8 specifications (RR {M['rob_min_rr']:.1f}-{M['rob_max_rr']:.1f}),
falls with distance from the fighting ({pct(M['dose_0_50'])} at 0-50 km vs 43% at 150-200 km) and is replicated in the Black Sea (38%).</li>
<li><b>Highly likely (Moderate):</b> ships are switching off deliberately. Competing hypotheses: switch-off {a_['H-A Deliberate switch-off']} inconsistencies,
reception gap {a_['H-C AIS reception gap']}, algorithm artefact {a_['H-D Matching artefact']}. Dark tankers are waiting at the Dubai and Fujairah anchorages.</li>
<li><b>Highly likely (Moderate):</b> the Hormuz littoral stays above its disruption threshold at least intermittently through Q3-2026 ({pct(M['fc_prob_above_thr'])} of simulated paths).</li>
<li><b>Likely (Moderate):</b> a disruption outlasts the SPR ({pct(M['km_p_gt_spr'])}). A six-week disruption, about 1 in 5, leaves a 30-day holding 12 days short.
Holding 45 days covers it.</li>
<li><b>Almost certain (High):</b> stand-off weapons (84% of war violence) now define the threat to depots, air bases, ports and POL nodes far from the front.</li></ul>
<h2>Economic transmission (open-source data)</h2><p>Brent rose from US${M['brent_prewar']:.0f} to a peak of US${M['brent_war_peak']:.0f};
the rupee weakened {M['fx_dep_pct']:+.1f}%. The war added about <b>US${M['extra_bill_usd_bn']:.0f} bn</b> to India's oil bill in 199 days. <b>Out-of-sample:</b> on 26 Jun the market was calm
(US${M['brent_at_cut']:.0f}) while the indicators read Red. Brent then rose {M['brent_oos_change']:.0f}%.</p>
<h2>Exposure</h2><p>At least <b>{M['ind_gulf_ships']} Indian-flagged ships</b> were operating inside the Gulf war zone in two weeks, together with India's Gulf energy imports,
westbound trade, the Chabahar and IMEC corridors and about nine million citizens in the GCC.</p>
<h2>Actions for decision</h2><ul>
<li><b>Joint (HQ IDS):</b> re-baseline POL, aviation fuel and critical-spares War Wastage Reserves on the survival curve, with a 35-45 day target (R7).</li>
<li><b>All Services:</b> give priority to layered air defence, counter-UAS, dispersal and hardening of rear-area nodes, and make GNSS resilience mandatory (R10-R12).</li>
<li><b>Joint / MDA:</b> fuse national SAR with AIS at IFC-IOR for automatic dark-ship cueing, and treat AIS identity as untrusted (R4, R5).</li>
<li><b>Joint:</b> keep the GCC non-combatant evacuation plan at execution readiness while indicator I4 is Amber or Red (R9).</li>
<li><b>Institutional:</b> set up a tri-service Data Analytics Cell to run the I&amp;W matrix and dashboard weekly (R3, R8).</li></ul>"""


def page(html_body):
    return f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}{IG.CSS}</style></head><body>{html_body}</body></html>"


# Print HTML to an A4 PDF with headless Chromium.
def render(browser, html_str, path):
    pg = browser.new_page()
    pg.set_content(html_str, wait_until="load")
    pg.pdf(path=str(path), format="A4", print_background=True,
           margin={"top": "20mm", "bottom": "18mm", "left": "22mm", "right": "18mm"})
    pg.close()


# Roman numerals for front-matter page numbers (i, ii, iii ...).
def roman(k):
    vals = [(10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")]
    out = ""
    for v, s in vals:
        while k >= v:
            out += s
            k -= v
    return out


# Build order: body -> find markers/pages -> front matter (twice, so its own page numbers settle) -> merge ->
# stamp page numbers and running header -> save.
def main():
    body = build_body()
    body_html = page("".join(body.parts))
    with sync_playwright() as p:
        br = p.chromium.launch(executable_path="/opt/pw-browsers/chromium-1194/chrome-linux/chrome")
        render(br, body_html, OUT / "_body.pdf")
        bd = fitz.open(OUT / "_body.pdf")
        pages = {}
        for i, pg_ in enumerate(bd):
            for mk in re.findall(r"@@([A-Z0-9_]+)@@", pg_.get_text()):
                pages.setdefault(mk, i + 1)
        for pg_ in bd:
            hits = [w for w in pg_.get_text("words") if "@@" in w[4]]
            for w in hits:
                pg_.add_redact_annot(fitz.Rect(w[:4]), fill=False)
            if hits:
                pg_.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_NONE)
        front = page(front_html(body, pages))
        render(br, front, OUT / "_front.pdf")
        fp = {}
        for i, pg_ in enumerate(fitz.open(OUT / "_front.pdf")):
            head = pg_.get_text().strip().split("\n")[0].strip()
            if head in ("ABSTRACT", "EXECUTIVE SUMMARY", "THE STUDY AT A GLANCE", "DATA ANALYTICS IN PLAIN WORDS", "LIST OF ABBREVIATIONS", "LIST OF FIGURES", "LIST OF TABLES"):
                fp.setdefault(head, roman(i + 1))
        front = page(front_html(body, pages, fp))
        render(br, front, OUT / "_front.pdf")
        WORD.mkdir(exist_ok=True)  # final HTML kept for the editable Word version (build_word.py)
        (WORD / "report_front.html").write_text(front)
        (WORD / "report_body.html").write_text(body_html)
        br.close()
    fr = fitz.open(OUT / "_front.pdf")
    doc = fitz.open()
    doc.insert_pdf(fr)
    doc.insert_pdf(bd)
    nf = len(fr)
    for i, pg_ in enumerate(doc):
        w, h = pg_.rect.width, pg_.rect.height
        if i == 0:
            continue
        label = roman(i + 1) if i < nf else str(i - nf + 1)
        pg_.insert_text((w / 2 - 6, h - 24), label, fontsize=10, fontname="times-roman")
        pg_.insert_text((62, 36), "CDM Datathon-2026  |  Global Conflicts - Impact on Supply Chains", fontsize=7.5,
                        fontname="helv", color=(0.45, 0.45, 0.45))
        pg_.draw_line((62, 41), (w - 51, 41), color=(0.75, 0.75, 0.75), width=0.4)
    doc.set_metadata({"title": f"{TITLE.title()} - CDM Datathon 2026", "author": AUTHOR,
                      "subject": "Global Conflicts - Impact on Supply Chains"})
    out = OUT / "Datathon2026_Global_Conflicts_Supply_Chains_Report.pdf"
    doc.save(out, garbage=4, deflate=True)
    for f in ("_body.pdf", "_front.pdf"):
        (OUT / f).unlink()
    print("pages:", len(doc), "front:", nf, "->", out)


if __name__ == "__main__":
    main()
